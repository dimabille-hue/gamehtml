# Tabletop Engine Distribution — 1.40.110

Install the engine package, create `game-packs/`, and copy one or more game-pack ZIPs into it.

```text
installation/
├── runtime/
├── launcher/
├── package.json
└── game-packs/
    ├── game-pack-dice-race.zip
    └── game-pack-last-sector.zip
```

Start with `npm start`. The launcher scans the external pack directory. Valid packs appear automatically with Player, TV and Preview links. The engine also accepts an unpacked pack directory for development/administration.
