# TABLETOP GAME ENGINE — README_FIRST / PROJECT CONTINUITY

**Назначение:** этот документ является стартовой точкой для продолжения проекта в новом чате или новой рабочей сессии. Он не заменяет техническую документацию и правила игр: он объясняет **как устроен проект, где искать подробности, что уже доказано, что нельзя случайно сломать и что делать дальше**.

**Текущая master-версия:** 1.40.110 (Preview Lab Last Citadel Siege Runtime Bridge; Last Citadel now previews through real Player/TV surfaces with deterministic siege states and privacy-safe TV projection)
**Текущий рабочий каталог:** 1.40.110 / Preview Lab продолжает поэтапную миграцию игровых пакетов на реальные Player/TV runtime surfaces, теперь включая Last Citadel и её напряжённые состояния осады.
**Правило сопровождения:** этот файл обновляется при каждом новом master archive. Если меняется game pack, в этом файле обновляются его версия, статус, краткая история и ближайший следующий gate.

---




## Game-pack certification handoff — 1.40.109

Архитектурный hardening движка завершён. Следующий контур — сертификация самих игр: техническая готовность отделена от gameplay/balance certification. Подробная матрица находится в `GAME_PACK_CERTIFICATION_1.40.109.md`.

Текущие диагностические balance warnings: **Last Citadel** (cohort strategies дают 0/80, 80/80, 0/80 и 80/80 wins) и **Resource Arena** (defensive/adaptive заметно доминируют в synthetic bot cohort). Это не доказательство ошибки правил, потому что профили не эквивалентны по силе, но это обязательные вопросы для human playtest.

## Distribution decoupling — 1.40.110

Engine and game packs are now separate distribution artifacts. The engine runtime contains no embedded game-pack tree in production builds. One game pack equals one ZIP; placing a valid pack ZIP into the external `game-packs/` directory makes it appear in Launcher automatically and exposes its Player, TV and Preview surfaces. Invalid/incompatible packs are isolated and reported rather than breaking valid packs.

The exact distribution contract is documented in `DISTRIBUTION_ARCHITECTURE_1.40.110.md`.

## Architecture audit handoff — 1.40.109

Текущий аудит доказал, что полного переписывания engine не требуется. Главная зона технического долга находится на границах Browser ↔ Runtime ↔ Launcher ↔ Game Pack. В 1.40.109 эти границы укреплены: browser-consumed modules имеют единый ESM contract, `runtime/` воспроизводимо материализуется из source-backed деревьев, launcher использует surface truth вместо hardcoded game IDs, а production Player/TV module graph проходит автоматическую проверку для всех 11 пакетов.

Полный разбор доказательств и исторических сравнений ведётся в `ARCHITECTURE_AUDIT_WORKLOG.md`. Результаты реального device/browser smoke, которые невозможно доказать внутри контейнера, должны оставаться отдельным release gate; успешный Node/module-graph тест не заменяет физическую проверку Android/TV.

# CURRENT MASTER STATUS — 1.40.110

Последний master: **1.40.110 — engine/game-pack distribution decoupling.** Full developer master, engine-only distribution and individual game-pack ZIPs are generated separately.

- **Preview Lab:** Dice Race, Resource Arena, Exploding Lite, Kitty Kaboom, Shifting Labyrinth, Frontier Lines и AFTERFALL имеют настоящий renderer bridge: сценарий Preview Lab отправляется через preview WebSocket в реальные Player/TV runtime surfaces. Для Shifting Labyrinth bridge передаёт полный пространственный snapshot 7×7 поля, игроков, свободную плитку, фазу и достижимые клетки; hidden-information пакеты сохраняют privacy projection. Остальные пакеты продолжают использовать совместимый scenario adapter до поэтапного переноса.

- **Exploding Lite:** `multi-screen-playable`, LAN human/device-test entry доступен через `npm run device-test:exploding-lite`.
- **Dice Race:** LAN playtest entry доступен через `npm run device-test:dice-race`.
- **Kitty Kaboom / ProtoGen:** имеют LAN playtest entry.
- **Last Citadel:** LAN playtest entry подтверждён и синхронизирован с Truth Model в 1.40.90; `live-playtest` теперь проверяется readiness gate.
- **Resource Arena:** LAN playtest entry подтверждён и синхронизирован с Truth Model в 1.40.88.
- **AFTERFALL:** существующий LAN device-test теперь подтверждён Truth Model и runtime metadata; запуск через `npm run device-test:afterfall`.
- **Catalog:** общий playtest-readiness audit связывает `liveEntry: true` с реальной npm-командой, executable entry и Player/TV capabilities.
- **Human Playtest Protocol:** `docs/current/HUMAN_PLAYTEST_PROTOCOL.md` задаёт единый evidence-format для всех LAN-ready пакетов; его catalog matrix автоматически проверяется regression test, поэтому следующий этап — реальные партии, а не декларативная готовность.
- **Shifting Labyrinth:** `playtest-ready` и LAN entry `npm run device-test:shift` дополнительно проверяются против source manifest и runtime registry; capability `live-playtest` больше не может потеряться между executable metadata и Truth Model.

**Обязательное правило:** при каждом изменении кода обновлять соответствующие tests, release/changelog и этот `README_FIRST.md`; документация не должна объявлять функцию готовой, если она отсутствует в executable runtime.

## CURRENT EXECUTABLE PLAYTEST MAP

Этот список является краткой картой реально запускаемых LAN/device-test entry. Он проверяется `test/documentation-truth.js` вместе с Truth Model, поэтому команды ниже не являются только документацией.

- **last-sector** — `npm run device-test`
- **dark-tides** — `npm run device-test:dark-tides`
- **protogen** — `npm run device-test:protogen`
- **kitty-kaboom** — `npm run device-test:kitty`
- **exploding-lite** — `npm run device-test:exploding-lite`
- **dice-race** — `npm run device-test:dice-race`
- **resource-arena** — `npm run device-test:resource-arena`
- **afterfall** — `npm run device-test:afterfall`
- **frontier-lines** — `npm run device-test:frontier`
- **shifting-labyrinth** — `npm run device-test:shift`
- **last-citadel** — `npm run device-test:citadel`


---

# 0. FINAL PRE-HUMAN-TEST GATE

**Release 1.40.37 status:** catalog remains frozen for human/real-device validation; this release fixes device-test auto-start, browser runtime, Russian-first UI, and TV map-first presentation.

Final audit conclusions recorded for the new chat handoff:
- source `core/` and executable `runtime/core/` were checked for parity; the earlier runtime drift was corrected in the 1.40.32 hotfix and is now enforced by `test/runtime-integrity.js`;
- registered runtime packs were checked for loadable entry points; the earlier missing `index.js` cases were corrected and runtime smoke coverage now checks every registered pack;
- AFTERFALL runtime was synchronized to 0.3.1; the Storm Basin route graph is part of the executable runtime;
- full project regression suite passes from the release tree;
- direct runtime smoke passes for all registered game packs;
- hot/heavy/render/WebSocket benchmarks were repeated; no evidence currently justifies moving the authoritative turn loop to Workers;
- retained rendering remains preferred for high-churn TV/Player scenes; full snapshot transport remains an exception path, not the normal per-command path;
- Kitty Kaboom seat/initiative results and ProtoGen strategy results are retained as **human-playtest balance questions**, not as reasons for emergency balance changes;
- Frontier Lines 0.1.0 is playable but gameplay-frozen; its next gate is human/device validation, not another feature cycle.

**What is allowed after this release:** only evidence-driven crash fixes, runtime parity/privacy/security fixes, or measured performance regressions. Gameplay changes require a human-playtest result or a clearly reproducible rules defect.

# 1. Как пользоваться этим документом

При переходе в новый чат сначала прочитать:

1. `README_FIRST.md` — этот файл;
2. `docs/current/ROADMAP.md` — авторитетный roadmap и архитектурные инварианты;
3. `docs/current/ARCHITECTURE.md` — краткая текущая архитектура;
4. `docs/current/TECHNICAL_AUDIT_2026-08-25_FINAL_PRE_HUMAN_TEST.md` — последний финальный технический аудит;
5. документацию конкретной игры, с которой продолжается работа.

Не пытаться восстанавливать историю проекта только по старым сообщениям чата. Архив и документация являются источником текущего состояния; история чата полезна только как дополнительный контекст.

---

# 1.1 Current catalog expansion decision

The current catalog is broad enough to pause major feature expansion until human/real-device testing. **Frontier Lines 0.1.0** is the current playable runtime preview; its gameplay is frozen for the real-device validation gate. The next preserved research directions remain **The Hidden City** (semi-cooperative city-building with hidden societies/private objectives) and **The Shifting Sea** (exploration on an expanding/changing public map).

Two additional ideas are intentionally preserved in the authoritative roadmap rather than started prematurely:

- **The Hidden City** — semi-cooperative city-building with hidden societies and private objectives;
- **The Shifting Sea** — exploration on an expanding/changing public map.

These are future research directions, not promises of immediate implementation. Their purpose is to ensure that useful ideas survive context transitions without fragmenting current priorities.

# 2. Главная идея проекта

Мы строим **универсальный, быстрый и компактный движок цифровых настольных игр**, а не один большой монолит под конкретную игру.

Цель движка — поддерживать разные жанры без переписывания ядра:

- тактические и board/hex игры;
- карточные игры;
- hidden-information игры;
- кооперативные игры;
- будущие игровые жанры, если их правила можно выразить через generic primitives.

Главный архитектурный инвариант:

> **Добавление новой игры не должно требовать изменения `core`.**

Это не означает «core никогда нельзя менять». Generic изменение допустимо только если новая потребность доказана минимальным game-agnostic кейсом, а не удобством одной конкретной игры.

Подробный roadmap и Definition of Done: `docs/current/ROADMAP.md`.

---

# 3. Архитектура — краткая карта

```text
core
  ↓
game rules / domains
  ↓
server / sessions / protocol
  ↓
generic Player / TV clients
  ↓
game-specific UI / presentation
```

## Core

Находится в `runtime/core/` и содержит generic primitives: state, commands, turns/phases, effects, reactions/decisions, triggers, scheduler, deterministic RNG, lifecycle, visibility, knowledge, projections, persistence/replay и events.

Core **не должен знать** о конкретных играх, карточках, hex-полях, TV, AI или конкретном транспорте.

Ключевые файлы включают:

- `runtime/core/game-engine.js`
- `runtime/core/turns.js`
- `runtime/core/effects.js`
- `runtime/core/events.js`
- `runtime/core/visibility.js`
- `runtime/core/knowledge.js`
- `runtime/core/random.js`
- `runtime/core/replay.js`
- `runtime/core/scheduler.js`

## Информационная модель

Всегда соблюдать:

```text
Authoritative State
       ↓
Knowledge
       ↓
Visibility policy
       ↓
Projection
       ↓
Client
```

Нельзя скрывать информацию только CSS/HTML/UI. Сервер и projection должны не выдавать приватные данные противнику.

## Событийная модель

Разделять:

```text
State events        → синхронизация игрового состояния
Presentation events → TV / FX / camera / choreography
```

Полный snapshot — для initial join, reconnect/resume, gap recovery и явного восстановления. Обычная работа должна использовать ограниченные event streams.

## Runtime и transport

- `runtime/server/` — sessions, match host, protocol, WebSocket, metrics;
- `runtime/client/` — state store, session/player/TV clients, reconnect/onboarding;
- `runtime/presentation/` — dispatcher, sequence runtime, camera, FX, frame scheduler;
- `runtime/game-packs/` и `runtime/game-packs.js` — регистрация и runtime integration game packs.

## Presentation

TV — **кинематографический свидетель**, а не источник правил. Правила остаются в authoritative state/game pack. Camera/FX/presentation потребляют presentation events.

Подробнее: `docs/current/ARCHITECTURE.md`, `presentation/`, `runtime/presentation/`.

---

# 4. Производительность и технические принципы

Приоритет проекта — **быстродействие без преждевременной архитектурной сложности**.

Текущая позиция:

- не выносить всё автоматически в workers/async только ради модного паттерна;
- сначала измерять hot path и реальную нагрузку;
- authoritative rules должны оставаться детерминированными и простыми;
- не блокировать UI тяжёлыми вычислениями, если реальный profiling покажет проблему;
- rendering/presentation должны быть отделены от rules;
- полные snapshots не использовать как обычный механизм каждого хода;
- AI/bots являются внешней validation layer, а не частью core;
- benchmark и stress-test использовать перед архитектурными оптимизациями.

Полезные команды:

```text
npm test
npm run bench:hot
npm run bench:render
npm run test:protogen
npm run device-test:protogen
npm run test:kitty
npm run test:afterfall
```

Последний зафиксированный аудит: `docs/current/TECHNICAL_AUDIT_2026-08-25.md` + `docs/current/TECHNICAL_AUDIT_2026-08-25_SECOND_PASS.md`.

Важно: при новой оптимизации сначала проверить, является ли она generic и действительно ли она улучшает measured bottleneck. Не ломать читаемую детерминированную архитектуру ради теоретической микрооптимизации.

---

# 5. Процесс разработки и принятия решений

## Правильный цикл

```text
Идея / design hypothesis
        ↓
Минимальная реализация внутри game pack
        ↓
Rules/regression tests
        ↓
Bots / seeded simulation / telemetry
        ↓
Разделить: баг правил vs ограничение AI vs баланс
        ↓
Осмысленный design/balance pass
        ↓
Human / real-device playtest
        ↓
Документация + roadmap + release archive
```

Не подгонять правила под один неудачный бот-прогон. Боты хорошо выявляют:

- зависания;
- недоступные действия;
- нарушение ливнеса;
- перекосы по инициативе/seat;
- доминирующие стратегии;
- недостаточно используемые механики;
- архитектурные и privacy regressions.

Но бот с плохой политикой не является доказательством плохого game design. Мы уже видели это на Station Zero и Split strategy AFTERFALL.

## Баланс первого игрока

Не вводить глобальный generic штраф/бонус первому игроку. Инициатива, random seating или компенсация должны быть **game-pack specific** и вводиться только после нормализованной статистики. Kitty Kaboom уже использует authoritative RNG для random first initiative.

## Изменение core

Перед любым core change:

1. сформулировать конкретное ограничение;
2. проверить, нельзя ли выразить его средствами game pack;
3. создать минимальный воспроизводимый generic кейс;
4. убедиться, что изменение полезно более чем одной игре;
5. добавить regression test и документацию.

## Честность релизов

Не заявлять, что баланс окончательно сертифицирован, если есть только bot evidence. Чётко различать:

- prototype / architecture evidence;
- bot baseline;
- statistical balance evidence;
- human playtest;
- production certification.

---

# 6. Процесс релизов и архивов

Это обязательная договорённость проекта.

### После каждого цикла изменений

1. обновить версии изменённых runtime/game-pack/manifest/registry/catalog мест;
2. обновить release notes/changelog/roadmap, если изменение влияет на планы или статус;
3. обновить **этот `README_FIRST.md`**;
4. прогнать релевантные тесты и полный regression suite, когда это уместно;
5. собрать **новый master archive с новым последовательным релизом**;
6. если менялся только конкретный game pack — дополнительно собрать отдельный архив game pack;
7. не включать старые master archives внутрь нового архива;
8. проверять release consistency и содержимое архива перед выдачей.

Новая версия архива не должна означать «случайно другой набор файлов». Если размер резко изменился — сначала аудит содержимого, затем релиз.

## Master archive

Содержит текущую актуальную рабочую версию проекта и документацию. Архивы старых релизов являются историей, но не должны рекурсивно вкладываться в новый master.

## Game-pack archive

Если изменён только game pack, выдавать:

- полный master archive;
- отдельный архив соответствующего game pack.

---

# 7. Документация: где правда

## Главные документы

- `README_FIRST.md` — handoff и процесс продолжения.
- `docs/current/ROADMAP.md` — авторитетный roadmap.
- `docs/current/ARCHITECTURE.md` — архитектурная карта.
- `docs/current/RELEASE_NOTES.md` — текущие release notes и история заметных релизов.
- `docs/current/TECHNICAL_AUDIT_2026-08-25.md` — последний аудит.

## Game-specific

Всегда сначала читать README и документы внутри `games/<game>/`.

## Старые документы

`docs/archive/` — исторический материал. Не считать старую версию документа автоматически актуальнее файла в `docs/current/`.

Если документы противоречат друг другу, сначала проверить version/date/release context и текущий код. Не «угадывать» примирение без фиксации причины.

---

# 8. Текущие игровые пакеты

## Last Sector — основной real-device validation target

**Статус:** playable-preview / главный практический тест runtime.

Жанр: sci-fi tactical exploration на board/hex поле.

Проверяет: deterministic board, movement, fuel, cargo/loot, combat, hidden map, hazards, save/load, projections, Player UI, TV presentation, tutorial, reconnect.

Главный текущий приоритет: **реальное тестирование на телефонах/TV/LAN**, затем production-grade TV cinematic presentation и camera choreography на основании реального feedback.

Документы: `games/last-sector/README.md`, `VISUAL_DESIGN.md`, `VISUAL_ASSETS.md`, `docs/current/TV_DEMO*.md` и roadmap.

## Тёмные Мели (Dark Tides)

**Статус:** playable-preview 1.0.0; validation ongoing.

Жанр: исследование проклятого архипелага, сокровища и конфликт капитанов.

Игроки: 2–6. Core loop: **Исследуй → Ищи → Вези → Сражайся → Возвращайся**.

Проверяет hidden hex map, private/public discoveries, cargo, PvP, storms, respawn, tutorial и TV presentation в другом жанре.

Следующий gate: real-device validation, fairness/balance simulation, presentation polish.

Документы: `games/dark-tides/README.md`, `RULES.md`, `docs/current/DARK_TIDES_*`.

## ProtoGen — Эволюция на грани

**Статус:** playable-playtest, версия 1.0.2-playtest; LAN human-playtest entry готов, balance certification pending.

Игроки: 2–6. Жанр: evolutionary strategy с процедурным микромиром, DNA, biomass, мутациями, размножением, боем, симбиозом и глобальными эпохами.

Уже проверены разные стратегии и скрытая информация. Важные прошлые выводы: исправлены bot liveness, NPC pressure, tie-break и privacy projection. Но требуется большой статистический balance pass и human playtest.

Текущий device-test entry: `npm run device-test:protogen` — 2–6 Player-устройств и общий TV.

Следующий gate: реальные human playtests плюс длинные seeded исследования по 2P/3P/4P/6P, стартовым позициям, способам победы и эволюционным стратегиям; затем один осмысленный balance pass.

Документы: `games/protogen/README.md`, `RULES.md`, `BALANCE_NOTES.md`.

## Kitty Kaboom

**Статус:** card-game architecture probe / playable playtest.

Назначение: стресс-тест private hands, deck zones, reactions, effect ordering, hidden information и elimination.

Уже проведены baseline и strategic studies; исправлена generic before-effect reaction resume semantics. Seat balance pass привёл к random first initiative через authoritative RNG, без generic core handicap.

Следующий gate: human playtest и дальнейшая проверка card-use frequency/баланса после живой игры.

Документы: `docs/current/KITTY_KABOOM_*`, код `games/kitty-kaboom/`.

## AFTERFALL

**Статус:** playable-playtest, версия 0.3.0; текущий активный design track.

Жанр: кооперативная карточно-пошаговая survival expedition с ощущением кинематографического side-scroller'а. Это не realtime platformer: TV создаёт движение, а решения дискретны и авторитетны.

Главная формула:

```text
движение → опасность → совет → тайный выбор → реакции → последствия → Advance World
```

Главные pillars: мир движется (`The Wake`), общая победа + личное авторство, карты взаимодействуют с миром, союзников невыгодно бросать, порталы — самостоятельные экспедиции, TV — cinematic witness.

### Текущая история AFTERFALL

- **0.1.x:** playable vertical slice, The Wake, private hands, Glass Garden.
- **0.1.6–0.1.9:** второй портал Station Zero; Temporal Loop Design Pass; отдельная стратегия и телеметрия; Glass Garden = быстрый/опасный, Station Zero = медленнее/надёжнее.
- **0.2.0–0.2.3:** Sunken Relay, альтернативные Ash Flats / Drainage Cut, Relay Gate, route/coordination bot studies. Важный вывод: Split-бот сначала был плохим AI, а не доказательством плохой split-механики.
- **0.2.4–0.2.5:** Relay Titan как Major Threat; затем readable intent, CHARGE → SHOCKWAVE и Overload phase для командной драматургии.
- **0.3.0:** Storm Basin. Beacon Alpha и Beacon Beta на параллельных ветках должны быть активированы до Storm Gate; затем обязательный regroup. Проверяется форма кооперации **split → achieve → converge**.

### Ближайший следующий шаг AFTERFALL

**Storm Basin Strategy Study** до дальнейшего расширения мира:

- обучить/адаптировать Cohesion, Split, Explorer, Adaptive и mixed policies;
- сравнить совместное и параллельное выполнение маяков;
- измерить стоимость regroup и давление The Wake;
- отделить проблемы AI от проблем дизайна;
- только после этого решать, нужен ли balance pass или следующий регион.

Документы: `games/afterfall/README.md`, `RULES.md`, `BOT_STUDY.md`, `PLAYTEST_NOTES.md`, `PORTALS_AND_EXPEDITIONS.md`, `SUNKEN_RELAY_NETWORK.md`, `MAJOR_THREAT_PROTOTYPE.md`, `STORM_BASIN.md`, `RELEASE_0.3.0.md`.

## Last Citadel — будущий инкубатор

**Статус:** concept/design prototype; не production game и не повод менять core.

Кооперативная карточно-тактическая RPG об обороне Цитадели. Формула: **Совет → тайный выбор → раскрытие → реакции/комбо → ход врагов → последствия → рост**.

Ключевой принцип: shared fate / personal authorship. Личные линии не должны поощрять вред команде.

Пока допустимы design/paper prototypes и маленькие engine-fit эксперименты. Большой ruleset не начинать до прохождения текущих приоритетов Last Sector.

Документы: `games/last-citadel/`.

## Gothic Night / Vampires & Werewolves

Сохранён как отдельный будущий setting seed, не объединять автоматически с AFTERFALL. Предполагаемый жанр — более медленная готическая стратегия/полукооперативная игра с территорией, ночью/днём, тайными намерениями и временными союзами.

Источник планов: `docs/current/ROADMAP.md`.

---

# 9. Текущее стратегическое направление

Основной приоритет не меняется только потому, что появились новые интересные идеи.

1. **Last Sector real-device validation** — практическая проверка Player phones + TV + LAN + reconnect.
2. На основании feedback — **TV cinematic presentation / camera choreography**.
3. Параллельно можно развивать game packs как архитектурные и design validation targets, не расширяя core без доказательства.
4. AFTERFALL сейчас активен как сложный кооперативный validation track; ближайший цикл — Storm Basin Strategy Study.
5. ProtoGen и Kitty Kaboom не считать окончательно сбалансированными только из-за bot results; human playtests остаются важным gate.
6. До реального тестирования не расширять игровой дизайн; разрешены только технические hotfix без изменения правил, если аудит находит блокирующую ошибку runtime/package.

---

# 10. Что обязательно проверить перед продолжением разработки

Перед большим новым изменением:

- прочитать этот файл и roadmap;
- посмотреть текущий код, а не опираться только на старые описания;
- определить, меняется ли core/runtime или только game pack;
- проверить версии manifest/runtime registry/launcher catalog;
- не потерять существующие game packs;
- при необходимости сначала провести targeted audit;
- после изменений обновить тесты и документацию;
- выпустить новый master archive, обновив этот handoff.

Если продолжение связано с конкретной игрой — сначала прочитать её README/rules/recent release file и только потом проектировать следующий шаг.

---

# 11. Чего не делать без отдельного доказательства

- Не превращать core в набор специальных функций AFTERFALL/Last Sector/карточной игры.
- Не переносить hidden data в UI и считать это privacy.
- Не балансировать под один слабый бот.
- Не добавлять глобальный first-player handicap всем играм.
- Не бесконечно наращивать контент, если предыдущая механика ещё не прошла validation.
- Не удалять или исключать файлы из master archive ради уменьшения размера без аудита.
- Не включать DevTools в end-user product.
- Не называть prototype production-ready без соответствующего тестирования.

---

# 12. Быстрый handoff для нового чата

Если этот файл прочитан в новом чате, правильное понимание проекта такое:

> У нас уже есть универсальный deterministic tabletop runtime с authoritative state, privacy/projection model, reconnect, event streams, generic Player/TV layers и independently versioned game packs. Ядро остаётся жанронейтральным. Мы доказываем архитектуру на нескольких очень разных играх и предпочитаем сначала реализовать новую механику внутри game pack, затем тестировать её правилами, ботами и людьми. После каждого изменения создаётся новый последовательный master archive, а этот файл обязательно обновляется. Если менялся только game pack, дополнительно выдаётся его отдельный архив. Текущий активный продуктовый приоритет — real-device validation всего замороженного каталога; AFTERFALL 0.3.1 и Frontier Lines 0.1.0 остаются в текущем playable состоянии до human playtest. Главный продуктовый приоритет при этом остаётся real-device validation Last Sector и последующая кинематографическая TV-доска.

---

# 13. Технический статус 1.40.37

Real-device testing выявил browser-runtime и device-test issues. 1.40.37 фиксирует только технические ошибки: запуск тестовой партии без tutorial gate, явный snapshot request и Russian-first Player/TV UI для текущих проверяемых паков. Игровые правила заморожены.

---

# 13. Поддержание документа

При каждом новом master release обновить минимум:

- master version/date;
- текущую базовую игровую версию, если она изменилась;
- статус и ближайший gate изменённой игры;
- раздел «Текущее стратегическое направление», если приоритеты изменились;
- любые новые обязательные процессные договорённости.

Этот файл должен оставаться **картой проекта**, а не журналом каждой строчки кода. Подробности должны жить в существующих специализированных документах, на которые здесь есть ссылки.


## Continuity update — 1.40.27

AFTERFALL is frozen at **0.3.1 Storm Basin Strategy Study**. The Relay Gate → Haven shortcut was removed because it allowed the full expedition to bypass the newly authored Storm Basin content. The deterministic study now records beacon telemetry, while a focused 120-seed coordination probe proves the distributed objective rules independently of generic bot route-discovery limitations.

**Current next gate:** human/real-device playtest of the existing expedition. Do not add another region before learning whether split → achieve → converge produces natural team discussion for humans.


## Continuity update — 1.40.31

### Frontier Lines

Frontier Lines has crossed the paper-design gate into its first playable runtime release, **0.1.0**, and is frozen for human/device validation. The game uses the Great Updraft fixed map (20 nodes, 36 corridors, 45 buildable slots, 9 double corridors), five navigation resource types, three private contracts per player, Chart/Build/Reframe actions, one-time Network Resonance bonuses, final network scoring, a Player UI and a TV UI.

The canonical visual direction is **Dirigible Atlas**: light curved sky lanes, parallel aerial corridors and an atlas-like TV presentation. Procedural map generation remains design-only until human playtest validates the fixed map. A first deterministic strategic study now covers 120 games across 2P/3P/4P/5P with chart-first, build-first and adaptive profiles; it is a regression/balance signal, not a substitute for human evidence.

### Immediate next gate

Pause feature expansion and run human/device playtest of Frontier Lines together with the existing catalog. Record route readability, double-corridor usefulness, contract tension, blocking/recovery, turn length, TV readability and perceived first-player advantage. Compare those observations with the deterministic 120-game bot baseline, but do not promote the pack based on bot results alone.


### Release 1.40.34 technical hotfix
- `/player` and `/tv` now redirect to real UI asset roots so relative CSS/JS/SVG files load correctly over LAN/mobile browsers.
- Runtime regression `test/device-test-assets.js` verifies Player CSS/JS and TV routing.
- No gameplay, balance, or core rules changes.


## 1.40.37 real-browser runtime correction
- Friendly `/player` and `/tv` device-test routes now redirect to the canonical game-pack asset paths so relative ES-module imports and SVG assets resolve correctly.
- Last Sector Player UI remains Russian-first; TV UI is map-first.
- TV runtime initialization order fixed so the DOM helper exists before camera/tactical objects are created.
- Human validation remains in progress; no game rules or balance changes.


## 1.40.37 browser-root correction
The previous device-test alias `/player-ui/index.html` exposed the game page under a virtual browser base, which broke relative ES-module imports such as `../assets.js` even though HTML/CSS could load. Device-test now redirects to the canonical `/games/last-sector/player-ui/index.html` and `/games/last-sector/tv-ui/index.html` paths. The TV client DOM helper is initialized before first use.


## 1.40.37 — Real Browser Runtime Correction
Current frozen technical release for human/real-device validation. This release fixes browser-base-path issues in the Last Sector device-test flow, the TV runtime initialization order, and keeps the current catalog Russian-first while preserving map-first TV presentation. No gameplay or balance changes.

## Актуальное состояние — 1.40.86

**Dice Race** теперь имеет LAN human-playtest entry: `npm run device-test:dice-race` запускает матч для 2–4 Player-устройств и отдельного TV. Актуальный путь пакета: **Gameplay → Strategic Validation → Player/TV → LAN Playtest**. После запуска используйте ссылки, напечатанные в консоли, для подключения устройств в одной Wi‑Fi сети.

При каждой следующей версии код, тесты, manifests/registry/Truth Model и документация обновляются совместно; `README_FIRST.md` является краткой актуальной точкой входа в проект.

## Preview Lab (LAN)
Run `npm run preview-lab` to open the shared visual preview session. Open `/` on a PC as controller, `/player` on Android, and `/tv` on the television. Selecting a game/scenario on the controller synchronizes the selected real game-pack preview adapter across connected screens. Preview is isolated from match persistence and does not execute gameplay commands.

Preview Lab 1.40.97 now validates role-specific Player and TV runtime preview surfaces with reproducible scenarios.

## Preview Lab — актуальное состояние 1.40.101

Preview Lab теперь является LAN-инструментом визуальной проверки: Controller работает на ПК, `/player` можно открыть на Android, а `/tv` — на телевизоре. Один выбор сценария синхронно переключает подключённые поверхности.

Пять пакетов уже проходят через **реальные runtime Player/TV renderers**: **Dice Race, Resource Arena, Exploding Lite, Kitty Kaboom и Shifting Labyrinth**. Для Shifting Labyrinth Preview использует полный snapshot реального пространственного состояния: 49 клеток, игроков, фазу, свободную плитку и достижимые маршруты — поэтому Android и TV показывают тот же тип сцены, что и настоящий runtime. Для игр со скрытой информацией Preview сохраняет privacy boundary: Player получает приватную руку, TV получает только публичные счётчики.

Следующее направление Preview: поэтапно переносить оставшиеся пакеты на реальные renderer bridges, не заменяя их универсальными мокапами.


## Preview Lab status — 1.40.106

AFTERFALL has joined the real runtime renderer bridge in LAN Preview Lab. Deterministic expedition scenarios now exercise the actual Player and TV surfaces with route progress, heroes, hazards, portals and major threats. The Player receives the private action hand while TV projection receives only public hand counts and expedition state.


## Preview Lab · 1.40.106
Dark Tides migrated to the real Player/TV runtime bridge. Preview scenarios now render the full 9×9 archipelago, fleet, threats and storm pressure on real surfaces; TV fixtures strip private cargo manifests.


## Preview Lab · 1.40.106
Last Citadel migrated to the real Player/TV runtime bridge. Preview scenarios now cover opening siege, active defense, late-game Hollow King pressure and finale; TV projection strips private card identities while retaining public hand counts.
