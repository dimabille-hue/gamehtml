# Distribution Architecture — 1.40.110

## Product boundary
There are two independent distribution families:

1. **Engine** — generic host/runtime. It contains no game implementation.
2. **Game Pack** — exactly one game per ZIP. It contains only that game's server rules, Player, TV, Preview and game-owned content/assets.

## Installation
```text
Tabletop/
├── runtime/
├── launcher/
├── package.json
└── game-packs/
    ├── game-pack-dice-race.zip
    ├── game-pack-last-sector.zip
    └── ...
```

The engine scans `game-packs/` dynamically. Copying a new valid game ZIP into that folder is sufficient to make the game appear in Launcher on the next catalog refresh.

## Runtime contract
Game packs may depend on engine functionality only through the public runtime contract. The distribution pack builder rewrites known Node engine imports to `TABLETOP_ENGINE_API_ROOT` and browser engine imports to `/client/browser/` and `/presentation/browser/`.

## Validation
A pack is accepted only when its manifest is valid, engine compatibility matches, its declared Player/TV surfaces exist, and its Preview exists. Invalid or incompatible packs are isolated and reported through `/pack-errors.json`.

## Independence
The engine can run with zero packs. Packs can be added, removed or replaced independently of the engine artifact.
