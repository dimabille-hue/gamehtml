'use strict';
const fs=require('node:fs');
const path=require('node:path');
const os=require('node:os');
const {extractZip,readEntries,readEntry}=require('./zip-reader');

const DEFAULT_PACK_DIR=()=>{
  if(process.env.TABLETOP_GAME_PACKS_DIR) return path.resolve(process.env.TABLETOP_GAME_PACKS_DIR);
  if(process.env.TABLETOP_DATA_DIR) return path.resolve(process.env.TABLETOP_DATA_DIR,'game-packs');
  const engineRoot=path.resolve(__dirname,'..');
  const installPacks=path.join(engineRoot,'game-packs');
  const sourceGames=path.join(engineRoot,'games');
  try { const pkg=JSON.parse(fs.readFileSync(path.join(engineRoot,'package.json'),'utf8')); if(pkg.private && fs.existsSync(sourceGames)) return sourceGames; } catch {}
  return installPacks;
};
function safeId(v){return typeof v==='string' && /^[a-z0-9][a-z0-9-]{0,63}$/.test(v);}
function parseVersion(v){const m=String(v||'').match(/^(\d+)\.(\d+)(?:\.(\d+))?/);return m?{major:+m[1],minor:+m[2],patch:+(m[3]||0)}:null;}
function compatible(range,engineVersion){
  if(!range) return true;
  const ev=parseVersion(engineVersion); if(!ev) return false;
  const exact=String(range).trim();
  if(exact==='1.40.x') return ev.major===1&&ev.minor===40;
  const parts=exact.split(/\s+/).filter(Boolean);
  for(const p of parts){
    const m=p.match(/^(>=|>|<=|<|=)?(\d+)\.(\d+)(?:\.(\d+))?/); if(!m) continue;
    const op=m[1]||'='; const v={major:+m[2],minor:+m[3],patch:+(m[4]||0)};
    const a=ev.major*1e6+ev.minor*1e3+ev.patch,b=v.major*1e6+v.minor*1e3+v.patch;
    if(op==='>'&&!(a>b)||op==='>='&&!(a>=b)||op==='<'&&!(a<b)||op==='<='&&!(a<=b)||op==='='&&!(a===b)) return false;
  }
  return true;
}
function readManifest(root,{distribution=false}={}){
  const file=path.join(root,'manifest.json');
  if(!fs.existsSync(file)) throw new Error('missing-manifest');
  const m=JSON.parse(fs.readFileSync(file,'utf8'));
  if(m.schemaVersion!==1) throw new Error('unsupported-pack-schema');
  if(!safeId(m.gameId)) throw new Error('invalid-game-id');
  if(!m.name || !m.version || !m.entry) throw new Error('invalid-manifest');
  if(!fs.existsSync(path.join(root,m.entry))) throw new Error('missing-entry');
  return m;
}
class GamePackHost{
 constructor(options={}){
  this.engineVersion=String(options.engineVersion||require('../package.json').version);
  this.packDir=path.resolve(options.packDir||DEFAULT_PACK_DIR());
  this.cacheDir=path.resolve(options.cacheDir||path.join(this.packDir,'.installed'));
  this.records=new Map(); this.errors=[];
 }
 refresh(){
  this.records.clear(); this.errors=[];
  fs.mkdirSync(this.packDir,{recursive:true}); fs.mkdirSync(this.cacheDir,{recursive:true});
  for(const name of fs.readdirSync(this.packDir).sort()){
   if(name.startsWith('.')) continue;
   const full=path.join(this.packDir,name);
   try{
    let root=full, source='directory', archive=null;
    const st=fs.statSync(full);
    if(st.isFile() && name.toLowerCase().endsWith('.zip')){
      const entries=readEntries(full);
      const manifestEntry=entries.get('manifest.json');
      if(!manifestEntry) throw new Error('missing-manifest');
      const manifest=JSON.parse(readEntry(manifestEntry).toString('utf8'));
      validateManifest(manifest,{distribution:true});
      if(!compatible(manifest.engineCompatibility,this.engineVersion)) throw new Error(`incompatible-engine:${manifest.engineCompatibility}`);
      const signature=`${st.size}:${Math.trunc(st.mtimeMs)}:${manifest.gameId}:${manifest.version}`;
      const cacheName=`${manifest.gameId}@${String(manifest.version).replace(/[^A-Za-z0-9._-]/g,'_')}`;
      const cacheRoot=path.join(this.cacheDir,cacheName), stamp=path.join(cacheRoot,'.source-signature');
      if(!fs.existsSync(path.join(cacheRoot,'manifest.json')) || !fs.existsSync(stamp) || fs.readFileSync(stamp,'utf8')!==signature){
        const temp=fs.mkdtempSync(path.join(this.cacheDir,'extract-'));
        try { extractZip(full,temp); const extractedRoot=fs.existsSync(path.join(temp,'manifest.json'))?temp:findSingleRoot(temp); fs.rmSync(cacheRoot,{recursive:true,force:true}); fs.renameSync(extractedRoot,cacheRoot); fs.rmSync(temp,{recursive:true,force:true}); }
        catch(e){fs.rmSync(temp,{recursive:true,force:true});throw e;}
        fs.writeFileSync(stamp,signature);
      }
      root=cacheRoot; source='zip'; archive=full;
    } else if(!st.isDirectory()) continue;
    const manifest=readManifest(root,{distribution:source==='zip'});
    if(!compatible(manifest.engineCompatibility,this.engineVersion)) throw new Error(`incompatible-engine:${manifest.engineCompatibility}`);
    if(this.records.has(manifest.gameId)) throw new Error(`duplicate-game-id:${manifest.gameId}`);
    const rec={...manifest,root,source,archive};
    this.records.set(manifest.gameId,rec);
   }catch(e){this.errors.push({file:name,error:e.message||String(e)});}
  }
 }
 list(){this.refresh(); return [...this.records.values()].map(({root,archive,...m})=>({...m}));}
 get(id){this.refresh(); const rec=this.records.get(String(id)); if(!rec) throw new Error('unknown-game-pack'); return {...rec};}
 resolveFile(id,relative){const r=this.get(id); const file=path.resolve(r.root,relative.replace(/^\/+/,'')); if(!file.startsWith(path.resolve(r.root)+path.sep)) throw new Error('pack-path-escape'); if(!fs.existsSync(file)) throw new Error('pack-file-not-found'); return file;}
 load(id){const r=this.get(id); const prev=process.env.TABLETOP_ENGINE_API_ROOT; process.env.TABLETOP_ENGINE_API_ROOT=__dirname; try{const mod=require(path.resolve(r.root,r.entry)); const manifest={...r}; delete manifest.root; delete manifest.archive; return {manifest,definition:mod,root:r.root};}finally{if(prev==null) delete process.env.TABLETOP_ENGINE_API_ROOT; else process.env.TABLETOP_ENGINE_API_ROOT=prev;}}
 errorsSnapshot(){return this.errors.slice();}
}
function validateManifest(m,{distribution=false}={}){
 if(!m) throw new Error('unsupported-pack-schema');
 if(distribution && m.schemaVersion!==1) throw new Error('unsupported-pack-schema');
 if(distribution&&m.packFormatVersion!==1) throw new Error('unsupported-pack-schema');
 if(!safeId(m.gameId)) throw new Error('invalid-game-id');
 if(!m.name||!m.version||!m.entry) throw new Error('invalid-manifest');
 if(!m.capabilities||!Array.isArray(m.capabilities)) throw new Error('missing-capabilities');
}
function readManifest(root,{distribution=false}={}){
 const file=path.join(root,'manifest.json');
 if(!fs.existsSync(file)) throw new Error('missing-manifest');
 const m=JSON.parse(fs.readFileSync(file,'utf8')); validateManifest(m,{distribution});
 if(!fs.existsSync(path.join(root,m.entry))) throw new Error('missing-entry');
 if(!fs.existsSync(path.join(root,'preview','index.html'))) throw new Error('missing-preview');
 if(m.capabilities.includes('player')&&!fs.existsSync(path.join(root,'player-ui','index.html'))) throw new Error('missing-player-surface');
 if(m.capabilities.includes('tv')&&!fs.existsSync(path.join(root,'tv-ui','index.html'))) throw new Error('missing-tv-surface');
 return m;
}

function findSingleRoot(temp){
 const entries=fs.readdirSync(temp,{withFileTypes:true});
 if(entries.length===1&&entries[0].isDirectory()&&fs.existsSync(path.join(temp,entries[0].name,'manifest.json'))) return path.join(temp,entries[0].name);
 return temp;
}
module.exports={GamePackHost,DEFAULT_PACK_DIR,compatible};
