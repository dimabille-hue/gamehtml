'use strict';

function validatePack(pack) {
  if (!pack || typeof pack !== 'object') throw new TypeError('content pack must be an object');
  if (!pack.id || typeof pack.id !== 'string') throw new Error('content pack id is required');
  if (!pack.version || typeof pack.version !== 'number') throw new Error('content pack version is required');
  return true;
}

function deepFreeze(value) {
  if (!value || typeof value !== 'object' || Object.isFrozen(value)) return value;
  Object.freeze(value);
  for (const child of Object.values(value)) deepFreeze(child);
  return value;
}

function createContentPack(pack) {
  validatePack(pack);
  return deepFreeze(structuredClone(pack));
}

function pick(pack, category, id) {
  return pack?.[category]?.[id] ?? null;
}

module.exports = { validatePack, createContentPack, pick };
