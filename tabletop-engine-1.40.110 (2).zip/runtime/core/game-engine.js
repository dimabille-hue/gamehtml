'use strict';

const { Random } = require('./random');
const { EventLog, PUBLIC } = require('./events');
const { TurnOrder } = require('./turns');
const { EffectStack } = require('./effects');
const { Scheduler } = require('./scheduler');
const { makeWindow, orderedResponses, allAnswered } = require('./timing');
const { GameError, assert, fail } = require('./errors');
const { hash } = require('./replay');
const { KnowledgeStore } = require('./knowledge');
const { projectFields } = require('./visibility');

// The kernel intentionally knows NOTHING about cards, decks, zones, resources,
// abilities, or any other game genre. Those belong to optional domain packages.
const ENGINE_VERSION = 13;
const DEFAULT_EVENT_CAPACITY = 1024;
const RESERVED_COMMANDS = new Set(['CHOOSE', 'REACT', 'PASS_REACTION', 'CLOSE_REACTION']);

function clone(value) {
  if (value == null || typeof value !== 'object') return value;
  if (typeof structuredClone === 'function') return structuredClone(value);
  return JSON.parse(JSON.stringify(value));
}

function createEngine(definition, options = {}) {
  assert(definition && typeof definition === 'object', 'definition-required');
  assert(typeof definition.project === 'function', 'projection-required');
  assert(!definition.actions || typeof definition.actions === 'object', 'invalid-actions');
  for (const action of Object.keys(definition.actions || {})) {
    assert(!RESERVED_COMMANDS.has(action), `reserved-command:${action}`);
  }

  const random = new Random(options.seed ?? Date.now());
  const events = new EventLog(options.eventCapacity || DEFAULT_EVENT_CAPACITY);
  const players = new Map();
  const turnOrder = new TurnOrder();
  const effects = new EffectStack();
  const scheduler = new Scheduler();
  const knowledge = new KnowledgeStore();
  const ruleLatch = new Set();
  const state = (typeof definition.createState === 'function'
    ? definition.createState({ seed: random.seed })
    : {}) || {};
  assert(state && typeof state === 'object' && !Array.isArray(state), 'invalid-state');

  const meta = {
    phase: 'lobby',
    revision: 0,
    turn: 1,
    active: null,
    pending: null,
    winner: null,
    started: false,
    finished: false,
    commandSeq: 0,
    setup: null,
    timing: null,
    currentEffect: null
  };

  const commandLogCapacity = Math.max(0, Number(options.commandLogCapacity ?? 0) | 0);
  const keepCommandHashes = options.commandHashes === true;
  const commandLog = [];
  const atomic = options.atomic === true;
  const atomicClone = atomic ? clone : null;

  // One reusable execution context. actor/action are dynamic getters, so the
  // hot path does not allocate a context object per command/effect.
  let currentActor = null;
  let currentAction = null;
  const api = buildApi();
  const context = buildContext();

  function buildContext() {
    const ctx = {
      get engine() { return api; },
      get state() { return state; },
      get actor() { return currentActor; },
      get action() { return currentAction; },
      get players() { return players; },
      get random() { return random; },
      get knowledge() { return knowledge; },
      emit,
      emitPresentation: (type, payload = {}, audience = PUBLIC) => emitPresentation(type, payload, audience),
      bump,
      endTurn,
      finish,
      eliminate: (id, reason = 'eliminated') => api.eliminate(id, reason),
      revive: id => api.revive(id),
      choose: beginDecision,
      reaction: beginReaction,
      enqueue,
      pushEffect: enqueue,
      schedule: scheduleEffect,
      cancelScheduled: id => scheduler.cancel(id),
      pushEffects: list => pushEffects(list),
      cancelEffect: () => { if (meta.currentEffect) meta.currentEffect.cancelled = true; },
      requireTurn: id => assert(meta.active === id, 'not-your-turn'),
      setPhase: phase => { meta.phase = phase; bump(); emit('PHASE_CHANGED', { phase }, PUBLIC); },
      setActive: id => { assert(players.has(id), 'unknown-player'); meta.active = id; turnOrder.set(turnOrder.ids, id); bump(); runDueScheduled(); },
      public: PUBLIC,
      scheduleAtTurn: (effect, turn) => scheduleEffect(effect, { atTurn: turn }),
      now: () => ({ command: meta.commandSeq, turn: meta.turn }),
      get phase() { return meta.phase; },
      get turn() { return meta.turn; },
      get active() { return meta.active; },
      get turnOrder() { return turnOrder; },
      get pending() { return meta.pending; },
      project(value, viewer, policies = {}) {
        return projectFields(value, policies, { viewer, knowledge: knowledge.get(viewer), state, players, phase: meta.phase, turn: meta.turn });
      }
    };

    // Optional domain services are injected by the definition. The kernel only
    // passes them through; it never imports or understands them.
    Object.defineProperty(ctx, 'services', {
      enumerable: true,
      get() { return definition.services || null; }
    });
    return ctx;
  }

  function buildApi() {
    return {
      version: ENGINE_VERSION,
      definitionId: definition.id || null,
      // These are intended for trusted server-side adapters and game code.
      // External clients must use snapshot()/events(), never these references.
      state,
      players,
      random,
      knowledge,
      get phase() { return meta.phase; },
      get revision() { return meta.revision; },
      get turn() { return meta.turn; },
      get active() { return meta.active; },
      get turnOrder() { return turnOrder; },
      get winner() { return meta.winner; },
      get pending() { return meta.pending; },
      project(value, viewer, policies = {}) {
        return projectFields(value, policies, { viewer, knowledge: knowledge.get(viewer), state, players, phase: meta.phase, turn: meta.turn });
      },
      get effects() { return effects; },
      get scheduled() { return scheduler.list(); },
      addPlayer(id, data = {}) {
        assert(meta.phase === 'lobby', 'game-already-started');
        assert(players.size < maxPlayers(), 'max-players-reached');
        assert(validId(id), 'invalid-player-id');
        assert(!players.has(id), 'player-exists');
        const record = { id, ready: data.ready !== false, connected: data.connected !== false, eliminated: false, ...data, id };
        players.set(id, record);
        knowledge.ensure(id);
        turnOrder.add(id);
        if (typeof definition.onPlayerJoin === 'function') invoke(null, 'PLAYER_JOIN', definition.onPlayerJoin, record);
        emit('PLAYER_JOINED', { player: id }, PUBLIC);
        return { ...record };
      },
      removePlayer(id) {
        assert(meta.phase === 'lobby', 'cannot-remove-during-game');
        assert(players.has(id), 'unknown-player');
        players.delete(id);
        knowledge.forget(id);
        turnOrder.remove(id);
        if (typeof definition.onPlayerLeave === 'function') invoke(null, 'PLAYER_LEAVE', definition.onPlayerLeave, id);
        emit('PLAYER_LEFT', { player: id }, PUBLIC);
      },
      updatePlayer(id, patch = {}) {
        assert(players.has(id), 'unknown-player');
        assert(patch && typeof patch === 'object' && !Array.isArray(patch), 'invalid-player-patch');
        const record = players.get(id);
        Object.assign(record, patch, { id });
        if (typeof definition.onPlayerUpdate === 'function') invoke(null, 'PLAYER_UPDATE', definition.onPlayerUpdate, { ...record });
        bump();
        emit('PLAYER_UPDATED', { player: id, patch }, PUBLIC);
        return { ...record };
      },
      knowledgeFor(viewer, create = true) { return create ? knowledge.ensure(viewer) : knowledge.get(viewer); },
      setKnowledge(viewer, value) { return knowledge.set(viewer, value); },
      mergeKnowledge(viewer, patch) { return knowledge.merge(viewer, patch); },
      forgetKnowledge(viewer) { return knowledge.forget(viewer); },
      ready(id, value = true) {
        assert(meta.phase === 'lobby', 'game-already-started');
        assert(players.has(id), 'unknown-player');
        players.get(id).ready = !!value;
        bump();
        emit('PLAYER_READY', { player: id, ready: !!value }, PUBLIC);
        return !!value;
      },
      setConnected(id, connected) {
        assert(players.has(id), 'unknown-player');
        const value = connected !== false;
        players.get(id).connected = value;
        bump();
        emit(value ? 'PLAYER_CONNECTED' : 'PLAYER_DISCONNECTED', { player: id }, PUBLIC);
        if (typeof definition.onConnectionChange === 'function') invoke(id, 'CONNECTION', definition.onConnectionChange, id, value);
        return value;
      },
      eliminate(id, reason = 'eliminated') {
        assert(players.has(id), 'unknown-player');
        const player = players.get(id);
        if (player.eliminated) return false;
        player.eliminated = true;
        turnOrder.remove(id);
        if (meta.active === id) meta.active = turnOrder.current();
        bump();
        emit('PLAYER_ELIMINATED', { player: id, reason }, PUBLIC);
        checkVictory();
        return true;
      },
      revive(id) {
        assert(players.has(id), 'unknown-player');
        const player = players.get(id);
        if (!player.eliminated) return false;
        player.eliminated = false;
        turnOrder.add(id);
        bump();
        emit('PLAYER_REVIVED', { player: id }, PUBLIC);
        return true;
      },
      start(startOptions = {}) {
        assert(meta.phase === 'lobby', 'game-already-started');
        assert(players.size >= minPlayers(), 'not-enough-players');
        assert(players.size <= maxPlayers(), 'max-players-reached');
        if (definition.requireReady !== false) assert([...players.values()].every(p => p.ready !== false), 'players-not-ready');
        if (typeof definition.validateSetup === 'function') invoke(null, 'VALIDATE_SETUP', definition.validateSetup, startOptions);
        meta.started = true;
        meta.phase = 'setup';
        meta.setup = startOptions;
        meta.active = turnOrder.current();
        if (typeof definition.setup === 'function') invoke(null, 'SETUP', definition.setup);
        if (meta.phase === 'setup') meta.phase = 'playing';
        bump();
        emit('GAME_STARTED', { players: [...players.keys()], turn: meta.turn, active: meta.active }, PUBLIC);
        stabilize();
        drainEffects();
        checkVictory();
        return api.snapshot(PUBLIC);
      },
      endTurn(next = null, options = {}) { return endTurn(next, options); },
      checkVictory,
      finish,
      choose(spec) { return beginDecision(spec); },
      reaction(spec) { return beginReaction(spec); },
      dispatch(actor, command) { return runDispatch(actor, command); },
      tryDispatch(actor, command) {
        try { return { ok: true, ...runDispatch(actor, command) }; }
        catch (error) { const e = normalizeError(error); return { ok: false, error: { code: e.code || 'game-error', message: e.message, meta: e.meta || null } }; }
      },
      availableActions(viewer) { return getAvailableActions(viewer); },
      snapshot(viewer = PUBLIC) { return makeSnapshot(viewer); },
      consumeEvents(viewer = PUBLIC, stream = 'state') { return events.consume(viewer, stream); },
      eventsSince(id, viewer = PUBLIC, stream = null) { return events.since(id, viewer, stream); },
      eventWindow(stream = null) { return events.window(stream); },
      save() { return saveState(); },
      load(save) { return loadState(save); },
      replayHash(viewer = PUBLIC) { return hash({ snapshot: makeSnapshot(viewer), knowledge: knowledge.snapshot(viewer), rng: random.serialize(), pending: meta.pending }); },
      commandLog() { return commandLog.map(entry => ({ ...entry })); },
      schedule(effect, options = {}) { return scheduleEffect(effect, options); },
      cancelScheduled(id) { return scheduler.cancel(id); }
    };
  }

  function runDispatch(actor, command) {
    validateActor(actor);
    validateCommand(command);
    const checkpoint = atomic ? makeCheckpoint() : null;
    const previousRevision = meta.revision;
    const commandSeq = ++meta.commandSeq;
    try {
      if (meta.pending) return dispatchPending(actor, command, commandSeq, previousRevision);
      assert(meta.phase === 'playing', 'game-not-playing');
      assert(meta.active === actor, 'not-your-turn');
      const action = definition.actions?.[command.type];
      assert(typeof action === 'function' && !RESERVED_COMMANDS.has(command.type), 'unknown-command');
      const result = invoke(actor, command.type, action, command);
      finishCommand(commandSeq, actor, command, result, previousRevision);
      if (meta.phase === 'playing') drainEffects();
      stabilize();
      return normalizeResult(result, previousRevision);
    } catch (error) {
      if (checkpoint) restoreCheckpoint(checkpoint);
      throw normalizeError(error);
    }
  }

  function dispatchPending(actor, command, commandSeq, previousRevision) {
    const p = meta.pending;
    if (p.kind === 'decision') {
      assert(p.player === actor, 'decision-not-yours');
      assert(p.commands.includes(command.type), 'choice-required');
      if (p.type === 'CHOOSE' || command.type === 'CHOOSE') validateChoice(p, command.value);
      meta.pending = null;
      bump();
      emit('DECISION_MADE', { id: p.id, player: actor, type: p.type, value: command.value ?? null, command: command.type }, PUBLIC);
      const resolver = definition.resolveDecision || definition.resolveChoice;
      if (typeof resolver === 'function') invoke(actor, command.type, resolver, p, command);
      finishCommand(commandSeq, actor, command, null, previousRevision);
      drainEffects();
      stabilize();
      return { value: command.value, revision: meta.revision, changed: meta.revision !== previousRevision };
    }
    if (p.kind === 'reaction') {
      if (command.type === 'CLOSE_REACTION') {
        assert(p.closeBy === actor, 'reaction-close-not-allowed');
        closeReaction(actor);
        finishCommand(commandSeq, actor, command, null, previousRevision);
        drainEffects();
        stabilize();
        return { revision: meta.revision, changed: meta.revision !== previousRevision };
      }
      assert(p.players.includes(actor), 'reaction-not-allowed');
      assert(command.type === 'REACT' || command.type === 'PASS_REACTION', 'reaction-required');
      const value = command.type === 'PASS_REACTION' ? null : command.value;
      if (command.type === 'REACT' && Array.isArray(p.options)) validateChoice(p, value);
      if (!p.responses[actor] || p.allowMultiple) {
        p.responses[actor] = { action: command.type, value };
        bump();
        emit('REACTION_RESPONSE', { id: p.id, player: actor, action: command.type, value: p.revealResponses ? value : undefined }, p.public ? PUBLIC : actor);
      }
      finishCommand(commandSeq, actor, command, null, previousRevision);
      if (p.closeWhen === 'first' || (p.closeWhen === 'all' && allAnswered(p))) closeReaction(actor);
      if (!meta.pending) drainEffects();
      stabilize();
      return { revision: meta.revision, complete: !meta.pending, changed: meta.revision !== previousRevision };
    }
    fail('invalid-pending-kind');
  }

  function finishCommand(seq, actor, command, result = null, previousRevision = meta.revision) {
    if (meta.revision === previousRevision) bump();
    if (!commandLogCapacity) return;
    const entry = { seq, actor, command, revision: meta.revision };
    if (result !== null) entry.result = serialResult(result);
    if (keepCommandHashes) entry.hash = api.replayHash(PUBLIC);
    commandLog.push(entry);
    if (commandLog.length > commandLogCapacity) commandLog.splice(0, commandLog.length - commandLogCapacity);
  }

  function serialResult(result) {
    if (result == null || typeof result !== 'object') return result ?? null;
    return clone(result);
  }

  function normalizeResult(result, previousRevision) {
    if (result && typeof result === 'object') return { ...result, revision: meta.revision, changed: meta.revision !== previousRevision };
    return { value: result ?? null, revision: meta.revision, changed: meta.revision !== previousRevision };
  }

  function beginDecision(spec = {}) {
    assert(!meta.pending, 'pending-already-exists');
    const player = spec.player ?? meta.active;
    assert(players.has(player), 'invalid-decision-player');
    const commands = Array.isArray(spec.commands) && spec.commands.length ? spec.commands.slice() : ['CHOOSE'];
    const pending = {
      id: events.nextId,
      kind: 'decision',
      player,
      type: spec.type || 'SELECT',
      options: spec.options == null ? null : spec.options,
      data: spec.data == null ? null : spec.data,
      commands,
      public: spec.public !== false
    };
    meta.pending = pending;
    bump();
    emit('DECISION_REQUIRED', publicPending(pending), pending.public ? PUBLIC : player);
    return pending;
  }

  function beginReaction(spec = {}) {
    assert(!meta.pending, 'pending-already-exists');
    const participants = [...new Set(spec.players || [...players.keys()])].filter(id => players.has(id));
    assert(participants.length > 0, 'no-reaction-players');
    const window = makeWindow({ id: events.nextId, ...spec, players: participants, priority: spec.priority || participants }, participants);
    const pending = {
      id: window.id,
      kind: 'reaction',
      type: window.type,
      timing: window.timing,
      players: window.participants,
      priority: window.priority,
      options: window.options == null ? null : window.options,
      data: window.data == null ? null : window.data,
      responses: Object.create(null),
      public: window.public,
      revealResponses: window.revealResponses,
      closeBy: spec.closeBy ?? window.priority[0],
      allowMultiple: window.allowMultiple,
      closeWhen: window.closeWhen,
      cancelOn: spec.cancelOn || null,
      resume: spec.resume || null
    };
    meta.timing = { type: pending.type, timing: pending.timing, id: pending.id };
    meta.pending = pending;
    bump();
    emit('REACTION_OPENED', publicPending(pending), pending.public ? PUBLIC : participants);
    return pending;
  }

  function closeReaction(actor) {
    const p = meta.pending;
    assert(p?.kind === 'reaction', 'no-reaction');
    meta.pending = null;
    meta.timing = null;
    bump();
    const responses = orderedResponses(p);
    emit('REACTION_CLOSED', { id: p.id, responses: p.revealResponses || p.public ? responses : responses.map(({ player, action }) => ({ player, action })) }, PUBLIC);
    const resume = p.resume;
    if (p.cancelOn && responses.some(response => responseMatchesCancel(p, response))) if (p.resume) p.resume.cancel = true;
    if (typeof definition.resolveReaction === 'function') {
      const resolution = invoke(actor, 'CLOSE_REACTION', definition.resolveReaction, p, responses);
      if (resolution?.cancel && p.resume) p.resume.cancel = true;
    }
    if (resume?.cancel === true) return;
    if (resume?.effect) effects.push({ ...resume.effect, __skipBeforeOnce: resume.phase === 'before' });
    if (resume?.effects) effects.pushMany(resume.effects);
    if (resume?.aftermath) effects.pushMany(asEffectList(resume.aftermath));
  }

  function responseMatchesCancel(window, response) {
    const rule = window?.cancelOn;
    if (!rule) return false;
    if (typeof rule === 'function') return !!rule(response);
    if (Array.isArray(rule)) return rule.some(item => matchesRule(response, item));
    return matchesRule(response, rule);
  }

  function matchesRule(value, rule) {
    for (const key of Object.keys(rule || {})) if (value[key] !== rule[key]) return false;
    return true;
  }

  function validateChoice(p, value) {
    if (!Array.isArray(p.options)) return;
    for (const option of p.options) if (sameValue(option, value)) return;
    fail('invalid-choice');
  }

  function sameValue(a, b) {
    if (a === b) return true;
    if (typeof a !== 'object' || typeof b !== 'object' || a == null || b == null) return false;
    return JSON.stringify(a) === JSON.stringify(b);
  }

  function endTurn(next = null, options = {}) {
    assert(!meta.pending, 'pending-decision');
    assert(meta.phase === 'playing', 'game-not-playing');
    const previous = meta.active;
    let nextId;
    if (!turnOrder.ids.length) { finish(null, 'no-active-players'); return null; }
    if (next != null) {
      assert(players.has(next) && !players.get(next).eliminated, 'invalid-next-player');
      const i = turnOrder.ids.indexOf(next);
      if (i >= 0) turnOrder.index = i;
      nextId = next;
    } else nextId = turnOrder.next(options.steps || 1);
    assert(nextId && players.has(nextId) && !players.get(nextId).eliminated, 'no-next-player');
    meta.active = nextId;
    meta.turn += 1;
    bump();
    emit('TURN_CHANGED', { from: previous, to: nextId, turn: meta.turn, reason: options.reason || null }, PUBLIC);
    runDueScheduled();
    return nextId;
  }

  function finish(winner, reason) {
    meta.finished = true;
    meta.phase = 'finished';
    meta.winner = winner ?? null;
    meta.pending = null;
    meta.timing = null;
    scheduler.clear();
    effects.clear();
    bump();
    emit('GAME_FINISHED', { winner: meta.winner, reason: reason || null }, PUBLIC);
  }

  function enqueue(effect) { assert(effect && typeof effect.type === 'string', 'invalid-effect'); effects.push(effect); }
  function pushEffects(list) { if (!Array.isArray(list)) return; effects.pushMany(list); }

  function drainEffects(limit = 2048) {
    let n = 0;
    while (effects.size && !meta.pending && meta.phase !== 'finished') {
      if (++n > limit) fail('effect-loop-limit');
      const effect = effects.pop();
      meta.currentEffect = effect;
      const actor = effect.actor ?? meta.active;
      if (!effect.__skipBeforeOnce && typeof definition.beforeEffect === 'function') {
        const gate = invoke(actor, `BEFORE:${effect.type}`, definition.beforeEffect, effect);
        if (gate?.cancel === true) { emit('EFFECT_CANCELLED', { type: effect.type, id: effect.id || null }, PUBLIC); meta.currentEffect = null; continue; }
        if (gate?.reaction) { meta.currentEffect = null; beginReaction({ ...gate.reaction, resume: { effect, phase: 'before' } }); return; }
      }
      const resolver = definition.effects?.[effect.type];
      assert(typeof resolver === 'function', 'unknown-effect', `Unknown effect: ${effect.type}`);
      const result = invoke(actor, `EFFECT:${effect.type}`, resolver, effect) || null;
      meta.currentEffect = null;
      if (result?.cancel === true) { emit('EFFECT_CANCELLED', { type: effect.type, id: effect.id || null }, PUBLIC); continue; }
      if (Array.isArray(result?.effects)) pushEffects(result.effects);
      if (!meta.pending && typeof definition.afterEffect === 'function') {
        const gate = invoke(actor, `AFTER:${effect.type}`, definition.afterEffect, effect, result);
        if (gate?.reaction) { beginReaction({ ...gate.reaction, resume: gate.resume === false ? null : undefined }); return; }
      }
      if (meta.phase !== 'finished') bump();
      stabilize();
    }
  }

  function stabilize() {
    if (meta.phase === 'finished') return;
    runDueScheduled();
    runStateBasedRules();
    if (meta.phase !== 'finished') checkVictory();
  }

  function runDueScheduled() {
    const due = scheduler.due(meta.commandSeq, meta.turn);
    if (!due.length) return;
    for (const item of due) effects.push(item.effect);
    emit('SCHEDULED_EFFECTS_READY', { count: due.length }, PUBLIC);
    if (!meta.pending && meta.phase !== 'finished') drainEffects();
  }

  function runStateBasedRules() {
    const rules = definition.stateBasedRules || definition.rules?.stateBased || [];
    if (!Array.isArray(rules) || !rules.length || meta.pending || effects.size) return;
    for (const rule of rules) {
      if (!rule || typeof rule.id !== 'string' || typeof rule.test !== 'function') continue;
      const matched = !!invoke(meta.active, `RULE:${rule.id}`, rule.test);
      if (!matched) { ruleLatch.delete(rule.id); continue; }
      if (ruleLatch.has(rule.id)) continue;
      ruleLatch.add(rule.id);
      const result = typeof rule.effect === 'function' ? invoke(meta.active, `RULE:${rule.id}`, rule.effect) : rule.effect;
      const list = Array.isArray(result) ? result : (result ? [result] : []);
      if (!list.length) continue;
      effects.pushMany(list);
      emit('STATE_RULE_TRIGGERED', { rule: rule.id, effects: list.map(e => e.type) }, PUBLIC);
    }
    if (effects.size && !meta.pending) drainEffects();
  }

  function emit(type, payload = {}, audience = PUBLIC) {
    const event = events.append(type, payload, audience, meta.revision, 'state');
    if (typeof definition.onEvent === 'function') invoke(meta.active, `EVENT:${type}`, definition.onEvent, event);
    const handlers = definition.triggers?.[type] || definition.rules?.triggers?.[type];
    if (handlers) runEventTriggers(event, handlers);
    return event;
  }

  function emitPresentation(type, payload = {}, audience = PUBLIC) {
    // Presentation events are output-only: they never feed state triggers or rules.
    return events.append(type, payload, audience, meta.revision, 'presentation');
  }

  function runEventTriggers(event, source) {
    const list = Array.isArray(source) ? source : [source];
    for (const handler of list) {
      const result = typeof handler === 'function' ? invoke(meta.active, `TRIGGER:${event.type}`, handler, event) : handler;
      const effectsList = Array.isArray(result) ? result : (result ? [result] : []);
      if (!effectsList.length) continue;
      effects.pushMany(effectsList);
      emit('TRIGGER_FIRED', { event: event.type, effects: effectsList.map(e => e.type) }, PUBLIC);
    }
  }

  function invoke(actor, action, fn, ...args) {
    const prevActor = currentActor;
    const prevAction = currentAction;
    currentActor = actor;
    currentAction = action;
    try { return fn(context, ...args); }
    finally { currentActor = prevActor; currentAction = prevAction; }
  }

  function scheduleEffect(effect, options = {}) {
    const inCommands = Math.max(0, Number(options.inCommands ?? options.delayCommands ?? 0) | 0);
    const atCommand = Number.isInteger(options.atCommand) ? options.atCommand : meta.commandSeq + inCommands;
    const atTurn = Number.isInteger(options.atTurn) ? options.atTurn : (Number.isInteger(options.inTurns) ? meta.turn + Math.max(0, options.inTurns | 0) : null);
    assert(atCommand >= meta.commandSeq, 'scheduled-command-in-past');
    const item = scheduler.schedule(effect, { command: atCommand, turn: atTurn }, { createdAt: meta.commandSeq, tag: options.tag });
    emit('EFFECT_SCHEDULED', { id: item.id, type: item.effect.type, due: item.due, tag: item.tag }, PUBLIC);
    return item;
  }

  function getAvailableActions(viewer) {
    let list;
    if (meta.pending) {
      if (meta.pending.kind === 'decision' && meta.pending.player === viewer) list = meta.pending.commands || ['CHOOSE'];
      else if (meta.pending.kind === 'reaction' && meta.pending.players.includes(viewer)) list = ['REACT', 'PASS_REACTION'];
      else if (meta.pending.kind === 'reaction' && meta.pending.closeBy === viewer) list = ['CLOSE_REACTION'];
      else list = [];
    } else if (meta.phase === 'playing' && meta.active === viewer) list = Object.keys(definition.actions || {});
    else list = [];
    if (typeof definition.availableActions === 'function') return definition.availableActions(context, viewer, list) || list;
    return list;
  }

  function makeSnapshot(viewer) {
    const base = {
      engine: ENGINE_VERSION,
      definition: definition.id || null,
      revision: meta.revision,
      phase: meta.phase,
      turn: meta.turn,
      active: meta.active,
      winner: meta.winner,
      pending: visiblePending(viewer),
      players: [...players.values()].map(publicPlayer),
      turnOrder: turnOrder.ids.slice(),
      availableActions: getAvailableActions(viewer)
    };
    const knowledgeView = viewer == null ? knowledge.get(null) : knowledge.get(viewer);
    return clone(definition.project(state, viewer, base, { viewer, knowledge: knowledgeView, state, players, phase: meta.phase, turn: meta.turn, active: meta.active }));
  }

  function saveState() {
    return {
      engine: ENGINE_VERSION,
      definition: definition.id || null,
      random: random.serialize(),
      meta: {
        ...meta,
        turnOrder: turnOrder.serialize(),
        effectStack: effects.toJSON(),
        scheduled: scheduler.list(),
        schedulerNextId: scheduler.sequence,
        ruleLatch: [...ruleLatch]
      },
      players: [...players.values()].map(p => clone(p)),
      state: clone(state),
      knowledge: knowledge.serialize(),
      events: events.serialize(),
      commandLog: commandLog.map(clone)
    };
  }

  function loadState(save) {
    assert(save && save.engine === ENGINE_VERSION, 'unsupported-save-version');
    assert(!meta.started, 'cannot-load-started-engine');
    random.seed = Number(save.random?.seed) >>> 0;
    random.state = save.random?.state;
    for (const key of Object.keys(state)) delete state[key];
    Object.assign(state, clone(save.state || {}));
    knowledge.restore(save.knowledge || []);
    players.clear();
    for (const p of save.players || []) { players.set(p.id, clone(p)); knowledge.ensure(p.id); }
    meta.phase = save.meta?.phase || 'lobby';
    meta.revision = Number(save.meta?.revision) >>> 0;
    meta.turn = Number(save.meta?.turn) || 1;
    meta.active = save.meta?.active ?? null;
    meta.pending = clone(save.meta?.pending ?? null);
    meta.winner = save.meta?.winner ?? null;
    meta.started = !!save.meta?.started;
    meta.finished = !!save.meta?.finished;
    meta.commandSeq = Number(save.meta?.commandSeq) || 0;
    meta.setup = clone(save.meta?.setup ?? null);
    meta.timing = clone(save.meta?.timing ?? null);
    turnOrder.restore(save.meta?.turnOrder || { ids: [...players.keys()], index: 0 });
    effects.clear(); effects.pushMany(save.meta?.effectStack || []);
    scheduler.clear();
    for (const item of save.meta?.scheduled || []) scheduler.schedule(item.effect, item.due, { id: item.id, createdAt: item.createdAt, tag: item.tag });
    scheduler.sequence = save.meta?.schedulerNextId || scheduler.sequence;
    ruleLatch.clear();
    for (const id of save.meta?.ruleLatch || []) ruleLatch.add(id);
    events.restore(save.events || {});
    commandLog.length = 0;
    if (commandLogCapacity) commandLog.push(...(save.commandLog || []).slice(-commandLogCapacity));
    return api.snapshot(PUBLIC);
  }

  function makeCheckpoint() {
    return {
      state: atomicClone(state),
      players: [...players.entries()].map(([id, player]) => [id, atomicClone(player)]),
      knowledge: knowledge.serialize(),
      meta: atomicClone(meta),
      random: random.serialize(),
      turnOrder: turnOrder.serialize(),
      effects: effects.toJSON(),
      scheduler: scheduler.list(),
      schedulerNextId: scheduler.sequence,
      ruleLatch: [...ruleLatch],
      events: events.serialize(),
      commandLog: commandLog.map(clone)
    };
  }

  function restoreCheckpoint(c) {
    for (const key of Object.keys(state)) delete state[key];
    Object.assign(state, c.state);
    players.clear();
    for (const [id, player] of c.players || []) players.set(id, clone(player));
    knowledge.restore(c.knowledge || []);
    Object.assign(meta, c.meta);
    random.seed = c.random.seed;
    random.state = c.random.state;
    turnOrder.restore(c.turnOrder);
    effects.clear(); effects.pushMany(c.effects);
    scheduler.clear();
    for (const item of c.scheduler) scheduler.schedule(item.effect, item.due, { id: item.id, createdAt: item.createdAt, tag: item.tag });
    scheduler.sequence = c.schedulerNextId;
    ruleLatch.clear();
    for (const id of c.ruleLatch) ruleLatch.add(id);
    events.restore(c.events);
    commandLog.length = 0;
    commandLog.push(...c.commandLog);
  }

  function checkVictory() {
    if (meta.phase !== 'playing' && meta.phase !== 'waiting') return null;
    if (typeof definition.victory !== 'function') return null;
    const result = invoke(meta.active, 'VICTORY', definition.victory);
    if (!result) return null;
    const winner = typeof result === 'string' ? result : result.winner ?? null;
    const reason = typeof result === 'string' ? 'victory' : result.reason ?? 'victory';
    finish(winner, reason);
    return { winner, reason };
  }

  function validateActor(actor) { assert(players.has(actor), 'unknown-player'); assert(!players.get(actor).eliminated, 'player-eliminated'); }
  function validateCommand(command) { assert(command && typeof command === 'object', 'invalid-command'); assert(typeof command.type === 'string' && command.type.length > 0 && command.type.length <= 64, 'invalid-command-type'); }
  function validId(id) { return typeof id === 'string' && id.length > 0 && id.length <= 64; }
  function publicPlayer(p) { return { id: p.id, name: p.name ?? null, ready: !!p.ready, connected: p.connected !== false, eliminated: !!p.eliminated }; }
  function visiblePending(viewer) {
    if (!meta.pending) return null;
    if (meta.pending.public || meta.pending.player === viewer || meta.pending.players?.includes(viewer) || meta.pending.closeBy === viewer) return publicPending(meta.pending);
    return null;
  }
  function publicPending(p) {
    const out = { id: p.id, kind: p.kind, type: p.type, public: p.public, data: p.data };
    if (p.kind === 'decision') {
      out.player = p.player; out.options = p.options; out.commands = p.commands.slice();
    } else {
      out.players = p.players.slice(); out.priority = p.priority.slice(); out.timing = p.timing;
      out.allowMultiple = p.allowMultiple; out.closeWhen = p.closeWhen; out.options = p.options;
      out.closeBy = p.closeBy; out.revealResponses = !!p.revealResponses;
      out.cancelOn = p.cancelOn; out.responses = p.revealResponses ? p.responses : Object.keys(p.responses).length;
    }
    return out;
  }
  function resolveCount(value, fallback) { const v = typeof value === 'function' ? value({ state, players, turn: meta.turn, phase: meta.phase }) : value; return Number(v ?? fallback) | 0; }
  function minPlayers() { return Math.max(1, resolveCount(definition.minPlayers, 1)); }
  function maxPlayers() { return Math.max(minPlayers(), resolveCount(definition.maxPlayers, 16)); }
  function bump() { meta.revision = (meta.revision + 1) >>> 0; }

  return api;
}

function normalizeError(error) {
  if (error instanceof GameError) return error;
  const e = new GameError('internal-error', error?.message || String(error));
  e.stack = error?.stack || e.stack;
  return e;
}

module.exports = { createEngine, PUBLIC, ENGINE_VERSION };
