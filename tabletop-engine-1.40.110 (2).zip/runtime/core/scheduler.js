'use strict';

const { assert } = require('./errors');

class Scheduler {
  constructor(items = []) {
    this.items = Array.isArray(items) ? items.map(clone) : [];
    this.nextId = this.items.reduce((m, x) => { const n = /^s(\d+)$/.exec(String(x.id || '')); return Math.max(m, n ? Number(n[1]) : 0); }, 0) + 1;
  }

  schedule(effect, due, meta = {}) {
    assert(effect && typeof effect.type === 'string', 'invalid-scheduled-effect');
    assert(Number.isInteger(due?.command) && due.command >= 0, 'invalid-due-command');
    const requestedId = meta.id;
    const id = requestedId ?? `s${this.nextId++}`;
    const numeric = /^s(\d+)$/.exec(String(id));
    if (numeric) this.nextId = Math.max(this.nextId, Number(numeric[1]) + 1);
    const item = {
      id,
      effect: clone(effect),
      due: { command: due.command, turn: Number.isInteger(due.turn) ? due.turn : null },
      createdAt: Number.isInteger(meta.createdAt) ? meta.createdAt : due.command,
      tag: meta.tag ?? null
    };
    this.items.push(item);
    this.sort();
    return clone(item);
  }

  due(command, turn) {
    const ready = [];
    const rest = [];
    for (const item of this.items) {
      const byCommand = item.due.command <= command;
      const byTurn = item.due.turn == null || item.due.turn <= turn;
      if (byCommand && byTurn) ready.push(item);
      else rest.push(item);
    }
    this.items = rest;
    this.sort();
    return ready;
  }

  cancel(id) {
    const before = this.items.length;
    this.items = this.items.filter(item => item.id !== id);
    return before !== this.items.length;
  }

  clear() { this.items.length = 0; }
  list() { return this.items.map(clone); }
  get sequence() { return this.nextId; }
  set sequence(value) { this.nextId = Math.max(1, Number(value) | 0); }
  get size() { return this.items.length; }
  sort() {
    this.items.sort((a, b) => (a.due.command - b.due.command) || ((a.due.turn ?? Infinity) - (b.due.turn ?? Infinity)) || String(a.id).localeCompare(String(b.id)));
  }
}

function clone(value) {
  if (typeof structuredClone === 'function') return structuredClone(value);
  return JSON.parse(JSON.stringify(value));
}

module.exports = { Scheduler };
