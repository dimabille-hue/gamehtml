'use strict';

const crypto = require('node:crypto');

function stable(value) {
  if (value === null || typeof value !== 'object') return JSON.stringify(value);
  if (Array.isArray(value)) return '[' + value.map(stable).join(',') + ']';
  return '{' + Object.keys(value).sort().map(k => JSON.stringify(k) + ':' + stable(value[k])).join(',') + '}';
}

function hash(value) {
  return crypto.createHash('sha256').update(stable(value)).digest('hex');
}

module.exports = { stable, hash };
