'use strict';

function clone(value) {
  if (value == null || typeof value !== 'object') return value;
  if (typeof structuredClone === 'function') return structuredClone(value);
  return JSON.parse(JSON.stringify(value));
}

function key(viewer) { return viewer == null ? null : viewer; }

class KnowledgeStore {
  constructor(initial = null) {
    this._items = new Map();
    if (initial) this.restore(initial);
  }

  ensure(viewer, initial = {}) {
    const k = key(viewer);
    let value = this._items.get(k);
    if (!value) {
      value = clone(initial) || {};
      this._items.set(k, value);
    }
    return value;
  }

  get(viewer) {
    return this._items.get(key(viewer)) || null;
  }

  set(viewer, value) {
    const k = key(viewer);
    this._items.set(k, clone(value) || {});
    return this._items.get(k);
  }

  merge(viewer, patch) {
    const value = this.ensure(viewer);
    if (patch && typeof patch === 'object' && !Array.isArray(patch)) Object.assign(value, clone(patch));
    return value;
  }

  forget(viewer) { return this._items.delete(key(viewer)); }
  clear() { this._items.clear(); }

  snapshot(viewer) {
    const value = this.get(viewer);
    return value == null ? null : clone(value);
  }

  serialize() {
    return [...this._items.entries()].map(([viewer, value]) => [viewer, clone(value)]);
  }

  restore(data) {
    this._items.clear();
    const rows = Array.isArray(data) ? data : [];
    for (const row of rows) {
      if (!Array.isArray(row) || row.length !== 2) continue;
      this._items.set(row[0], clone(row[1]) || {});
    }
  }

  get size() { return this._items.size; }
}

module.exports = { KnowledgeStore };
