'use strict';

const PUBLIC = null;
const PUBLIC_CURSOR = '@public-viewer';

function cursorKey(viewer) {
  if (viewer == null) return PUBLIC_CURSOR;
  if (Array.isArray(viewer)) return `@set:${viewer.slice().sort().join('|')}`;
  return String(viewer);
}

function audienceContains(audience, viewer) {
  if (audience === PUBLIC) return true;
  if (Array.isArray(audience)) return audience.includes(viewer);
  return audience === viewer;
}

/**
 * Bounded event store optimized for many viewers.
 *
 * The old implementation scanned every cursor and filtered the whole event
 * array whenever capacity was exceeded. With many sessions this made append
 * cost proportional to client count. This implementation keeps a bounded
 * chronological ring plus per-stream indexes, so append is O(1) amortized and
 * reads only scan the selected stream's bounded history.
 */
class EventLog {
  constructor(capacity = 1024) {
    this.capacity = Math.max(32, Number(capacity) | 0);
    this.nextId = 1;
    this.streamSeq = new Map();
    this.cursors = new Map();
    this._ring = new Array(this.capacity);
    this._head = 0;
    this._count = 0;
    this._streams = new Map();
  }

  _stream(streamName) {
    let state = this._streams.get(streamName);
    if (!state) {
      state = { items: [], head: 0 };
      this._streams.set(streamName, state);
    }
    return state;
  }

  _chronological() {
    const out = new Array(this._count);
    for (let i = 0; i < this._count; i++) out[i] = this._ring[(this._head + i) % this.capacity];
    return out;
  }

  _compactStream(state) {
    if (state.head < 256 || state.head * 2 < state.items.length) return;
    state.items = state.items.slice(state.head);
    state.head = 0;
  }

  _evictOldest() {
    if (!this._count) return;
    const event = this._ring[this._head];
    this._ring[this._head] = undefined;
    this._head = (this._head + 1) % this.capacity;
    this._count--;
    const state = this._streams.get(event.stream);
    if (state && state.items[state.head] === event) {
      state.head++;
      this._compactStream(state);
    }
  }

  append(type, payload = {}, audience = PUBLIC, revision = 0, stream = 'state') {
    const streamName = String(stream || 'state');
    const seq = (this.streamSeq.get(streamName) || 0) + 1;
    this.streamSeq.set(streamName, seq);
    const event = Object.freeze({ id: this.nextId++, seq, revision, type, payload, audience, stream: streamName });

    if (this._count >= this.capacity) this._evictOldest();
    const pos = (this._head + this._count) % this.capacity;
    this._ring[pos] = event;
    this._count++;
    this._stream(streamName).items.push(event);
    return event;
  }

  visible(viewer = PUBLIC, stream = null) {
    if (stream != null) return this._visibleStream(String(stream || 'state'), viewer);
    return this._chronological().filter(event => audienceContains(event.audience, viewer));
  }

  _visibleStream(streamName, viewer) {
    const state = this._streams.get(streamName);
    if (!state) return [];
    const out = [];
    for (let i = state.head; i < state.items.length; i++) {
      const event = state.items[i];
      if (audienceContains(event.audience, viewer)) out.push(event);
    }
    return out;
  }

  consume(viewer = PUBLIC, stream = 'state') {
    const streamName = String(stream || 'state');
    const key = `${streamName}::${cursorKey(viewer)}`;
    const last = this.cursors.get(key) || 0;
    const state = this._streams.get(streamName);
    if (!state) return [];
    const out = [];
    let newest = last;
    for (let i = state.head; i < state.items.length; i++) {
      const event = state.items[i];
      if (event.seq > last) {
        newest = Math.max(newest, event.seq);
        if (audienceContains(event.audience, viewer)) out.push(event);
      }
    }
    this.cursors.set(key, newest);
    return out;
  }

  since(cursor = 0, viewer = PUBLIC, stream = null) {
    const n = Number(cursor) || 0;
    if (stream != null) {
      const streamName = String(stream || 'state');
      const state = this._streams.get(streamName);
      if (!state) return [];
      const out = [];
      for (let i = state.head; i < state.items.length; i++) {
        const event = state.items[i];
        if (event.seq > n && audienceContains(event.audience, viewer)) out.push(event);
      }
      return out;
    }
    return this._chronological().filter(event => event.id > n && audienceContains(event.audience, viewer));
  }

  cursor(viewer = PUBLIC, stream = 'state') {
    return this.cursors.get(`${String(stream || 'state')}::${cursorKey(viewer)}`) || 0;
  }

  window(stream = null) {
    if (stream == null) {
      const items = this._chronological();
      return { oldest: items.length ? items[0].id : this.nextId, newest: items.length ? items[items.length - 1].id : this.nextId - 1 };
    }
    const streamName = String(stream || 'state');
    const state = this._streams.get(streamName);
    const latest = this.streamSeq.get(streamName) || 0;
    if (!state || state.head >= state.items.length) return { oldest: latest + 1, newest: latest };
    return { oldest: state.items[state.head].seq, newest: state.items[state.items.length - 1].seq };
  }

  // Compatibility getter. It materializes the bounded history only when a
  // caller explicitly asks for the complete event list.
  get items() { return this._chronological(); }

  get size() { return this._count; }

  clear() {
    this.cursors.clear();
    this.streamSeq.clear();
    this._streams.clear();
    this._ring = new Array(this.capacity);
    this._head = 0;
    this._count = 0;
    this.nextId = 1;
  }

  serialize() {
    return {
      capacity: this.capacity,
      nextId: this.nextId,
      streamSeq: Object.fromEntries(this.streamSeq),
      items: this._chronological().map(e => ({ ...e })),
      cursors: Object.fromEntries(this.cursors)
    };
  }

  restore(data) {
    this.clear();
    this.nextId = Number(data?.nextId) || 1;
    this.streamSeq = new Map(Object.entries(data?.streamSeq || {}).map(([k, v]) => [k, Number(v) || 0]));
    const items = Array.isArray(data?.items) ? data.items.slice(-this.capacity) : [];
    for (const raw of items) {
      const stream = String(raw.stream || 'state');
      const seq = Number(raw.seq) || ((this.streamSeq.get(stream) || 0) + 1);
      this.streamSeq.set(stream, Math.max(this.streamSeq.get(stream) || 0, seq));
      const event = Object.freeze({ ...raw, stream, seq });
      if (this._count >= this.capacity) this._evictOldest();
      const pos = (this._head + this._count) % this.capacity;
      this._ring[pos] = event;
      this._count++;
      this._stream(event.stream).items.push(event);
    }
    if (!this.streamSeq.size) {
      for (const event of this._chronological()) this.streamSeq.set(event.stream, Math.max(this.streamSeq.get(event.stream) || 0, event.seq));
    }
    this.cursors = new Map(Object.entries(data?.cursors || {}).map(([k, v]) => [k, Number(v) || 0]));
  }
}

module.exports = { PUBLIC, audienceContains, EventLog };
