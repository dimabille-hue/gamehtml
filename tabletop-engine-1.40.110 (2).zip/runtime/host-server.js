'use strict';
const http=require('node:http');
const {createServer:createWsServer}=require('./server/websocket');
const {MatchHost}=require('./server/match-host');
const {GamePackHost}=require('./pack-host');
const {serve:serveLauncher}=require('../launcher/server');

const engineVersion=require('../package.json').version;
const packHost=new GamePackHost({engineVersion,packDir:process.env.TABLETOP_GAME_PACKS_DIR});
const hosts=new Map();
function parsePath(requestPath){
  const u=new URL(requestPath||'/', 'ws://tabletop');
  const m=u.pathname.match(/^\/games\/([^/]+)$/);
  if(!m) return null;
  return {gameId:decodeURIComponent(m[1]),matchId:String(u.searchParams.get('match')||'default')};
}
function getGameHost(gameId){
  if(hosts.has(gameId)) return hosts.get(gameId);
  const pack=packHost.load(gameId);
  const h=new MatchHost({disconnectGraceMs:120000});
  hosts.set(gameId,h); h.createMatch('default',()=>pack.definition);
  return h;
}
function startServer(){
 const ws=createWsServer({port:Number(process.env.DEVICE_WS_PORT||process.env.WS_PORT||8080),host:process.env.DEVICE_HOST||process.env.WS_HOST||'0.0.0.0',onSession(session){
  try{
   const route=parsePath(session.path); if(!route) return session.close(1008);
   const host=getGameHost(route.gameId);
   if(!host.getMatch(route.matchId)){const pack=packHost.load(route.gameId);host.createMatch(route.matchId,()=>pack.definition);}
   host.attach(route.matchId,session);
  }catch(error){session.close(1008);}
 }});
 const httpServer=http.createServer(serveLauncher); const httpPort=Number(process.env.PORT||8090);
 return Promise.all([
  ws.listen(),
  new Promise((resolve,reject)=>{httpServer.once('error',reject);httpServer.listen(httpPort,'0.0.0.0',resolve);})
 ]).then(()=>{console.log(`Tabletop Engine ${engineVersion}: HTTP ${httpPort}, WebSocket ${process.env.DEVICE_WS_PORT||process.env.WS_PORT||8080}, game-packs=${packHost.packDir}`);return {ws,httpServer};});
}
function stopServer({ws,httpServer}={}){httpServer?.close?.(()=>{});ws?.close?.().catch?.(()=>{});for(const h of hosts.values())for(const id of [...h.matches.keys()])h.removeMatch(id);}
if(require.main===module){startServer().catch(error=>{console.error(error);process.exitCode=1;});process.on('SIGINT',stopServer);process.on('SIGTERM',stopServer);}
module.exports={packHost,hosts,parsePath,getGameHost,startServer,stopServer};
