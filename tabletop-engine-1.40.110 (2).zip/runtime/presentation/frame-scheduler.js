'use strict';

/**
 * Coalesces UI work to at most one flush per animation frame.
 * Browser code may pass requestAnimationFrame/cancelAnimationFrame explicitly;
 * Node/tests fall back to a microtask-like timer.
 */
class FrameScheduler {
  constructor(flush, options = {}) {
    if (typeof flush !== 'function') throw new TypeError('flush-required');
    this.flush = flush;
    this.raf = options.requestAnimationFrame || (typeof requestAnimationFrame === 'function' ? requestAnimationFrame : fn => setTimeout(() => fn(Date.now()), 0));
    this.cancel = options.cancelAnimationFrame || (typeof cancelAnimationFrame === 'function' ? cancelAnimationFrame : clearTimeout);
    this.pending = false;
    this.handle = null;
    this.latest = undefined;
  }
  schedule(value) {
    this.latest = value;
    if (this.pending) return;
    this.pending = true;
    this.handle = this.raf(() => {
      this.pending = false;
      this.handle = null;
      const value = this.latest;
      this.latest = undefined;
      this.flush(value);
    });
  }
  cancelPending() {
    if (!this.pending) return;
    this.cancel(this.handle);
    this.pending = false;
    this.handle = null;
    this.latest = undefined;
  }
}
module.exports = { FrameScheduler };
