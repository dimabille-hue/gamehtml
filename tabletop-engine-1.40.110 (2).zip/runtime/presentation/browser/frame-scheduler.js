// AUTO-GENERATED BROWSER MODULE. DO NOT EDIT.
// Source: presentation/frame-scheduler.js
// Source SHA-256: 7e4d3141102d603f7103f8e6781f46cad8d42248070d03867c75146f997bfd2e

/**
 * Coalesces UI work to at most one flush per animation frame.
 * Browser code may pass requestAnimationFrame/cancelAnimationFrame explicitly;
 * Node/tests fall back to a microtask-like timer.
 */
class FrameScheduler {
  constructor(flush, options = {}) {
    if (typeof flush !== 'function') throw new TypeError('flush-required');
    this.flush = flush;
    this.raf = options.requestAnimationFrame || (typeof requestAnimationFrame === 'function' ? requestAnimationFrame : fn => setTimeout(() => fn(Date.now()), 0));
    this.cancel = options.cancelAnimationFrame || (typeof cancelAnimationFrame === 'function' ? cancelAnimationFrame : clearTimeout);
    this.pending = false;
    this.handle = null;
    this.latest = undefined;
  }
  schedule(value) {
    this.latest = value;
    if (this.pending) return;
    this.pending = true;
    this.handle = this.raf(() => {
      this.pending = false;
      this.handle = null;
      const value = this.latest;
      this.latest = undefined;
      this.flush(value);
    });
  }
  cancelPending() {
    if (!this.pending) return;
    this.cancel(this.handle);
    this.pending = false;
    this.handle = null;
    this.latest = undefined;
  }
}
export { FrameScheduler };
