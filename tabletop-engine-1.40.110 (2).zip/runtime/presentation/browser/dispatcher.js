// AUTO-GENERATED BROWSER MODULE. DO NOT EDIT.
// Source: presentation/dispatcher.js
// Source SHA-256: 9a516a10d562035589c8e26e5eabded8bde1cb5b96b81fa3fc99e75c23c65bb0

/**
 * Generic event-to-presentation dispatcher. It knows nothing about any game.
 * Game packages register event names to render descriptors or render callbacks.
 */
class PresentationDispatcher {
  constructor(options = {}) { this.handlers = new Map(Object.entries(options.handlers || {})); this.fallback = options.fallback || null; }
  register(eventType, handler) { if (typeof handler !== 'function' && !handler) throw new TypeError('handler-required'); this.handlers.set(String(eventType), handler); return this; }
  dispatch(events, context = {}) {
    const out = [];
    for (const event of events || []) {
      const handler = this.handlers.get(event.type) || this.fallback;
      if (!handler) continue;
      out.push(typeof handler === 'function' ? handler(event, context) : handler);
    }
    return out;
  }
}
export { PresentationDispatcher };
