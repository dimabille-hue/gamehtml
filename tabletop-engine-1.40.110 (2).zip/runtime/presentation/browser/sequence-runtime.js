// AUTO-GENERATED BROWSER MODULE. DO NOT EDIT.
// Source: presentation/sequence-runtime.js
// Source SHA-256: 60d06d8f3830e5ae3d6cd1732369e2bd72a3dd67efbf803a59d1d3aebaf31ac7

/**
 * Generic presentation sequence scheduler.
 * No knowledge of games or DOM. Runs small effect scenes with lanes/priority.
 */
class PresentationSequenceRuntime {
  constructor(options = {}) {
    this.fx = options.fxRuntime || null;
    this.maxConcurrent = Math.max(1, Number(options.maxConcurrent ?? 4));
    this.active = new Map();
    this.seq = 0;
  }

  play(sequence, context = {}) {
    if (!sequence || !Array.isArray(sequence.steps) || !sequence.steps.length) return null;
    const id = ++this.seq;
    const key = sequence.key ? String(sequence.key) : `scene:${id}`;
    const priority = Number(sequence.priority ?? 0);
    const lane = sequence.lane ? String(sequence.lane) : 'default';

    if (sequence.replace) this.cancelLane(lane, priority);
    if (this.active.size >= this.maxConcurrent) {
      const victim = [...this.active.values()].sort((a, b) => a.priority - b.priority || a.id - b.id)[0];
      if (victim && victim.priority <= priority) victim.cancel();
      else return null;
    }

    let cancelled = false;
    let timer = null;
    const controller = {
      id, key, lane, priority,
      cancel: () => {
        cancelled = true;
        if (timer) clearTimeout(timer);
      }
    };
    this.active.set(id, controller);

    const run = async () => {
      for (const step of sequence.steps) {
        if (cancelled) break;
        const wait = Math.max(0, Number(step?.delay ?? 0));
        if (wait) await new Promise(resolve => { timer = setTimeout(resolve, wait); });
        if (cancelled) break;
        if (step?.camera && context?.camera) {
          const camera = step.camera;
          if (camera.choreograph && Array.isArray(camera.shots)) context.camera.choreograph(camera.shots, camera.options || {});
          else if (camera.track && Array.isArray(camera.track)) context.camera.track(camera.track, camera.options || {});
          else if (camera.reset) context.camera.reset(camera.options || camera);
          else if (camera.focus) context.camera.focus(camera.point || camera, camera.options || camera);
        }
        if (step?.descriptor && this.fx) {
          this.fx.play(typeof step.descriptor === 'function' ? step.descriptor(context) : step.descriptor);
        }
        if (step?.parallel && Array.isArray(step.parallel) && this.fx) {
          for (const descriptor of step.parallel) {
            if (cancelled) break;
            this.fx.play(typeof descriptor === 'function' ? descriptor(context) : descriptor);
          }
        }
        const hold = Math.max(0, Number(step?.hold ?? 0));
        if (hold) await new Promise(resolve => { timer = setTimeout(resolve, hold); });
      }
    };
    run().finally(() => {
      if (timer) clearTimeout(timer);
      this.active.delete(id);
    });
    return controller;
  }

  cancel(key) {
    const target = [...this.active.values()].find(x => x.key === String(key));
    if (target) target.cancel();
  }

  cancelLane(lane, minPriority = Number.POSITIVE_INFINITY) {
    for (const controller of this.active.values()) {
      if (controller.lane === String(lane) && controller.priority <= minPriority) controller.cancel();
    }
  }

  clear() {
    for (const controller of this.active.values()) controller.cancel();
    this.active.clear();
  }
}

export { PresentationSequenceRuntime };
