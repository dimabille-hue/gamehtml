# Tabletop Runtime 1.40.1

Runtime distribution contains the universal engine/server/client/presentation layers, launcher and installed game packs.

Installed packs in this build:
- Last Sector 1.40.1 — playable-preview
- Тёмные Мели 1.0.0 — playable-preview
- Протоген: Эволюция на грани 1.0.1-playtest — playable-playtest
- Kitty Kaboom 1.40.2 — playable playtest (card-game architecture probe)
- Exploding Lite 1.40.1 — prototype
- Dice Race 1.40.1 — validation
- Resource Arena 1.40.1 — validation

Developer editors and tests are not included.
