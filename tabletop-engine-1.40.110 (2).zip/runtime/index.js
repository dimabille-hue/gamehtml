'use strict';
module.exports = {
  ...require('./core/game-engine'),
  ...require('./core/effects'),
  ...require('./core/timing'),
  ...require('./core/scheduler'),
  ...require('./core/events'),
  ...require('./core/random'),
  ...require('./core/turns'),
  ...require('./core/errors'),
  ...require('./core/knowledge'),
  ...require('./core/visibility'),
  server: require('./server'),
  client: {
    SessionClient: require('./client/session-client').SessionClient,
    PlayerClient: require('./client/player-client').PlayerClient,
    TvClient: require('./client/tv-client').TvClient,
    ClientRuntime: require('./client/runtime').ClientRuntime,
    ClientStateStore: require('./client/state-store').ClientStateStore,
    createWebSocketTransport: require('./client/transports/websocket').createWebSocketTransport
  },
  presentation: {
    PresentationDispatcher: require('./presentation/dispatcher').PresentationDispatcher
  },
  gamePacks: require('./game-packs')
};
