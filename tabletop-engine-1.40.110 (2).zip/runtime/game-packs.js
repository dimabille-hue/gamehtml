'use strict';
const {GamePackHost}=require('./pack-host');
const host=new GamePackHost();
function list(){ return host.list(); }
function get(gameId){ return host.get(gameId); }
function load(gameId){ return host.load(gameId); }
function configure(options){ return new GamePackHost(options); }
function errors(){ host.list(); return host.errorsSnapshot(); }
module.exports={list,get,load,configure,errors,host};
