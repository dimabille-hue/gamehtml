'use strict';

const { assert } = require('../../core/errors');

// Canonical mutable zone abstraction. The backing object is intentionally plain
// so it stays JSON/save/replay friendly. Runtime methods mutate that backing object.
class Zone {
  constructor(id, cards = [], options = {}) {
    assert(typeof id === 'string' && id.length > 0, 'invalid-zone-id');
    if (cards && !Array.isArray(cards) && typeof cards === 'object') {
      this.zone = cards;
      this.zone.id ||= id;
      this.zone.cards ||= [];
    } else {
      this.zone = { id, cards: Array.isArray(cards) ? cards : [] };
    }
    this.random = options.random || null;
  }

  get id() { return this.zone.id; }
  get cards() { return this.zone.cards; }
  get size() { return this.zone.cards.length; }
  isEmpty() { return this.zone.cards.length === 0; }
  top() { return this.zone.cards.length ? this.zone.cards[this.zone.cards.length - 1] : null; }
  push(card) {
    this._ensureCapacity(1);
    this.zone.cards.push(card);
    return card;
  }
  pushMany(cards) {
    const list = Array.isArray(cards) ? cards : [];
    this._ensureCapacity(list.length);
    this.zone.cards.push(...list);
    return list.length;
  }
  pop() { return this.zone.cards.pop() ?? null; }
  popMany(count) {
    const n = Math.max(0, Math.min(Number(count) | 0, this.zone.cards.length));
    return n ? this.zone.cards.splice(this.zone.cards.length - n, n).reverse() : [];
  }
  draw(count = 1) { return this.popMany(count); }
  drawOne() { return this.pop(); }
  remove(cardId) {
    const i = this.zone.cards.findIndex(card => card && card.id === cardId);
    return i < 0 ? null : this.zone.cards.splice(i, 1)[0];
  }
  clear() { return this.zone.cards.splice(0); }
  _ensureCapacity(count) {
    const capacity = this.zone.capacity;
    if (Number.isFinite(capacity)) assert(this.zone.cards.length + count <= capacity, 'zone-capacity-exceeded');
  }
  shuffle(random = this.random) {
    assert(random && typeof random.shuffle === 'function', 'random-required');
    random.shuffle(this.zone.cards);
    return this;
  }
  toJSON() {
    const out = { ...this.zone, cards: this.zone.cards.slice() };
    return out;
  }
}

class Deck extends Zone {
  refillFrom(discard, random = this.random, count = 0) {
    const cards = discard.clear();
    if (cards.length === 0) return 0;
    if (random) random.shuffle(cards);
    let used = cards;
    if (count > 0) used = cards.splice(0, Math.min(count, cards.length));
    this.pushMany(used);
    return used.length;
  }
}

function createDeck(id, cards, random) {
  const deck = new Deck(id, cards, { random });
  if (random) deck.shuffle(random);
  return deck;
}

function draw(zone, count = 1) {
  assert(zone && typeof zone.popMany === 'function', 'invalid-zone');
  return zone.popMany(count);
}

function shuffle(zone, random) {
  assert(zone && typeof zone.shuffle === 'function', 'invalid-zone');
  return zone.shuffle(random);
}

module.exports = { Zone, Deck, createDeck, draw, shuffle };
