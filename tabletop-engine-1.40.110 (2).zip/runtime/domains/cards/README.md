# Optional Card Domain

This package is deliberately outside `core/`. The kernel does not know about
cards, decks, hands, zones, resources, abilities, or card DSL.

Use it only for games that need the card-oriented building blocks.
