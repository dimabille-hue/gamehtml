'use strict';

const { assert } = require('../../core/errors');
const { makeCards } = require('./cards');

class DeckBuilder {
  constructor(cardRegistry = null) {
    this.cardRegistry = cardRegistry;
    this.parts = [];
  }

  add(type, count = 1, overrides = {}) {
    const n = Math.max(0, Number(count) | 0);
    assert(typeof type === 'string' && type.length > 0, 'invalid-card-type');
    if (this.cardRegistry) this.cardRegistry.require(type);
    this.parts.push({ type, count: n, ...overrides });
    return this;
  }

  addMany(counts) {
    for (const [type, count] of Object.entries(counts || {})) this.add(type, count);
    return this;
  }

  repeat(builder, times = 1) {
    assert(builder && Array.isArray(builder.parts), 'invalid-deck-builder');
    for (let i = 0; i < Math.max(0, Number(times) | 0); i++) this.parts.push(...builder.parts.map(p => ({ ...p })));
    return this;
  }

  build(prefix = 'card') {
    const specs = this.parts.map(part => ({ ...part }));
    return makeCards(specs, prefix);
  }

  count() { return this.parts.reduce((n, p) => n + p.count, 0); }
  toJSON() { return this.parts.map(p => ({ ...p })); }
}

function fixedDeck(spec = {}, registry = null) {
  const builder = new DeckBuilder(registry);
  return builder.addMany(spec);
}

function composeDecks(...builders) {
  const out = new DeckBuilder(builders[0]?.cardRegistry || null);
  for (const builder of builders) out.repeat(builder, 1);
  return out;
}

module.exports = { DeckBuilder, fixedDeck, composeDecks };
