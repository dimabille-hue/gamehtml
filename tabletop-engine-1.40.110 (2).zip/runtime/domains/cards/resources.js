'use strict';

const { assert } = require('../../core/errors');

function integer(value, fallback = 0) {
  const n = Number(value);
  return Number.isFinite(n) ? Math.trunc(n) : fallback;
}

class ResourceBook {
  constructor(state, definitions = {}) {
    assert(state && typeof state === 'object', 'resource-state-required');
    this.state = state;
    this.definitions = new Map(Object.entries(definitions));
    this.state.resources ||= {};
  }

  define(id, definition = {}) {
    assert(typeof id === 'string' && id.length > 0, 'invalid-resource-id');
    const current = this.definitions.get(id) || {};
    this.definitions.set(id, { ...current, ...definition });
    return this.definitions.get(id);
  }

  has(id) { return this.definitions.has(id); }
  definition(id) { return this.definitions.get(id) || null; }
  require(id) { const d = this.definition(id); assert(d, 'unknown-resource', `Unknown resource: ${id}`); return d; }

  ensurePlayer(player) {
    this.state.resources[player] ||= {};
    for (const [id, def] of this.definitions) {
      if (this.state.resources[player][id] == null) this.state.resources[player][id] = integer(def.initial, 0);
      this.state.resources[player][id] = this._clamp(id, this.state.resources[player][id]);
    }
    return this.state.resources[player];
  }

  get(player, id) {
    this.require(id);
    this.ensurePlayer(player);
    return integer(this.state.resources[player][id]);
  }

  set(player, id, value) {
    this.require(id);
    this.ensurePlayer(player);
    this.state.resources[player][id] = this._clamp(id, integer(value));
    return this.state.resources[player][id];
  }

  add(player, id, amount) {
    return this.set(player, id, this.get(player, id) + integer(amount));
  }

  canSpend(player, cost) {
    for (const [id, amount] of this._entries(cost)) if (this.get(player, id) < amount) return false;
    return true;
  }

  spend(player, cost) {
    const entries = this._entries(cost);
    assert(this.canSpend(player, cost), 'insufficient-resources');
    for (const [id, amount] of entries) this.set(player, id, this.get(player, id) - amount);
    return entries;
  }

  grant(player, cost) {
    for (const [id, amount] of this._entries(cost)) this.add(player, id, amount);
    return true;
  }

  transfer(from, to, cost) {
    assert(this.canSpend(from, cost), 'insufficient-resources');
    this.spend(from, cost);
    this.grant(to, cost);
  }

  snapshot(player) {
    this.ensurePlayer(player);
    return { ...this.state.resources[player] };
  }

  publicSnapshot(players) {
    const out = {};
    for (const id of players) out[id] = this.snapshot(id);
    return out;
  }

  _entries(cost) {
    if (cost == null) return [];
    if (Array.isArray(cost)) return cost.flatMap(item => this._entries(item));
    if (typeof cost === 'string') return [[cost, 1]];
    if (typeof cost === 'object') return Object.entries(cost).map(([id, amount]) => [id, integer(amount)]).filter(([, amount]) => amount > 0);
    return [];
  }

  _clamp(id, value) {
    const def = this.require(id);
    let out = integer(value);
    if (Number.isFinite(def.min)) out = Math.max(integer(def.min), out);
    if (Number.isFinite(def.max)) out = Math.min(integer(def.max), out);
    return out;
  }
}

function defineResources(definitions) {
  return Object.fromEntries(Object.entries(definitions || {}).map(([id, d]) => [id, { ...d }]));
}

module.exports = { ResourceBook, defineResources };
