'use strict';
const { TYPE, frame, decode } = require('./protocol');
const { ServerMetrics } = require('./metrics');
const { ResumeStore } = require('./session-store');
const { normalizePlan } = require('./onboarding');
const TYPE_NAME = new Map(Object.entries(TYPE).map(([k,v])=>[v,k]));
function assert(c,code){if(!c){const e=new Error(code);e.code=code;throw e;}}

class MatchHost{
 constructor(options={}){this.options=options;this.matches=new Map();this.sessions=new Map();this.maxDedup=Math.max(32,options.commandDedup??128);this.metrics=options.metrics||new ServerMetrics();this.resumeStore=options.resumeStore||new ResumeStore({ttlMs:options.resumeTtlMs??120000});this.disconnectGraceMs=Math.max(0,Number(options.disconnectGraceMs??120000));}
 createMatch(id,definitionOrFactory,engineOptions={}){assert(typeof id==='string'&&id.length>0&&id.length<=96,'invalid-match-id');assert(!this.matches.has(id),'match-exists');const m=new Match(id,definitionOrFactory,engineOptions,this);this.matches.set(id,m);this.metrics.matchCreate();return m;}
 getMatch(id){return this.matches.get(id)||null;}
 removeMatch(id){const m=this.matches.get(id);if(!m)return false;m.close();this.matches.delete(id);return true;}
 attach(matchId,session){const m=this.matches.get(matchId);if(!m)throw new Error('match-not-found');if(!session||typeof session.send!=='function')throw new TypeError('session-send-required');const sid=String(session.id);const previous=this.sessions.get(sid);if(previous&&previous!==session&&typeof previous.close==='function')previous.close(4001,'replaced');this.sessions.set(sid,session);this.metrics.sessionOpen();return m.attach(session);}
 detach(sessionId){if(this.sessions.delete(String(sessionId)))this.metrics.sessionClose();}
 snapshotMetrics(){return this.metrics.snapshot();}
 prune(){this.resumeStore.prune();for(const m of this.matches.values())m.pruneDisconnected();}
}

class Match{
 constructor(id,definitionOrFactory,engineOptions,host){this.id=id;this.definitionOrFactory=definitionOrFactory;this.engineOptions=engineOptions;this.host=host;this.engine=null;this.definition=null;this.sessions=new Map();this.playerSessions=new Map();this.viewerSessions=new Map();this.disconnected=new Map();this.principalCommands=new Map();this.onboarding=null;this.pendingStart=null;}
 ensureEngine(){if(this.engine)return this.engine;const definition=typeof this.definitionOrFactory==='function'?this.definitionOrFactory():this.definitionOrFactory;this.definition=definition;const {createEngine}=require('../core/game-engine');this.engine=createEngine(definition,this.engineOptions);return this.engine;}
 start(options={}){const plan=this.getOnboarding();if(plan?.gateStart&&!options?.bypassTutorial){if(this.pendingStart)return {queued:true,tutorial:true};this.pendingStart={options:{...options},deadline:Date.now()+plan.autoStartAfterMs};this.onboarding={status:'playing',startedAt:Date.now(),plan};this.broadcastTutorial();this._tutorialTimer=setTimeout(()=>this.completeTutorial('timeout'),plan.autoStartAfterMs);this._tutorialTimer.unref?.();return {queued:true,tutorial:true};}const out=this.ensureEngine().start(options);this.onboarding=plan?{status:'completed',plan,completedAt:Date.now()}:null;this.broadcast();return out;}
 ready(player,value=true){const out=this.ensureEngine().ready(player,value);this.flushPrincipal('player',player,true);return out;}
 attach(session){
  const st={id:String(session.id),session,role:null,principal:null,resumeToken:null,lastEvent:0,lastEvents:{state:0,presentation:0},streams:null,alive:true,disconnectedAt:0};
  this.sessions.set(st.id,st);
  const originalClose=session.close;
  const originalOnClose=session.onClose;
  session.onClose=()=>{if(st.alive)this.detach(st);if(typeof originalOnClose==='function')originalOnClose();};
  session.close=(...args)=>{if(!st.alive)return;this.detach(st);if(typeof originalClose==='function')return originalClose.apply(session,args);};
  const originalReceive=session.receive;
  const controller={receive:p=>this.receive(st,p),close:()=>session.close?.()};
  this.send(st,frame(TYPE.WELCOME,{match:this.id,engine:this.ensureEngine().version,protocol:1,resumeSupported:true,roles:['player','viewer'],onboarding:this.getOnboarding()}));
  return controller;
 }
 detach(st){
  if(!st.alive){this.sessions.delete(st.id);return;}
  st.alive=false;
  this.sessions.delete(st.id);
  if(st.role==='player'&&st.principal&&this.playerSessions.get(st.principal)===st){this.playerSessions.delete(st.principal);if(this.engine?.players.has(st.principal)){this.engine.setConnected(st.principal,false);st.disconnectedAt=Date.now();this.disconnected.set(st.principal,st.disconnectedAt);}}
  if(st.role==='viewer'&&st.principal&&this.viewerSessions.get(st.principal)===st)this.viewerSessions.delete(st.principal);
  this.host.detach(st.id);
 }
 pruneDisconnected(){if(!this.disconnectGraceMs)return;const now=Date.now();for(const [player,at] of this.disconnected){if(now-at>this.disconnectGraceMs){this.disconnected.delete(player);this.host.resumeStore.revokePlayer(this.id, player);}}}
 receive(st,payload){try{const msg=decode(payload);switch(msg.t){case TYPE.HELLO:return this.onHello(st,msg);case TYPE.JOIN:return this.onJoin(st,msg);case TYPE.READY:return this.onReady(st,msg);case TYPE.COMMAND:return this.onCommand(st,msg);case TYPE.RESUME:return this.onResume(st,msg);case TYPE.SNAPSHOT_REQ:return this.onSnapshot(st);case TYPE.PING:return this.send(st,frame(TYPE.PONG,{ts:msg.ts??null}));case TYPE.TUTORIAL_DONE:return this.onTutorialDone(st,msg);default:return this.send(st,frame(TYPE.REJECT,{code:'unknown-message-type',t:msg.t}));}}catch(e){this.host.metrics.commandError();return this.sendError(st,e);}}
 onHello(st,msg){if(msg.protocol!=null&&msg.protocol!==1)return this.sendError(st,new Error('unsupported-protocol-version'));this.send(st,frame(TYPE.WELCOME,{match:this.id,engine:this.ensureEngine().version,protocol:1,resumeSupported:true,roles:['player','viewer'],onboarding:this.getOnboarding()}));}
 onJoin(st,msg){
  const e=this.ensureEngine();
  assert(!st.role,'already-joined');
  const role=msg.role==='viewer'?'viewer':'player';
  const requestedStreams=Array.isArray(msg.streams)?msg.streams.map(String):null;
  const defaultStreams=role==='viewer'?['state','presentation']:['state'];
  const allowedStreams=Array.isArray(this.host.options.eventStreams)&&this.host.options.eventStreams.length?this.host.options.eventStreams.map(String):['state','presentation'];
  st.streams=(requestedStreams||defaultStreams).filter(stream=>allowedStreams.includes(stream));
  if(!st.streams.length) st.streams=['state'];
  const token=String(msg.resumeToken||'');
  let principal=msg.id!=null?String(msg.id):String(msg.player||'');
  let resumed=null;
  if(token){const rec=this.host.resumeStore.consume(token,this.id,principal||null,role);if(rec){resumed=rec;principal=rec.principal;}}
  if(role==='player'){
   assert(principal.length>0&&principal.length<=64,'invalid-player-id');
   if(!e.players.has(principal)){assert(!token,'invalid-resume-token');e.addPlayer(principal,msg.data||{});}else{assert(resumed,'invalid-resume-token');e.setConnected(principal,true);}
  } else {
   assert(!token || resumed,'invalid-resume-token');
   if(!principal)principal=`viewer-${st.id}`;
   assert(principal.length<=96,'invalid-viewer-id');
   assert(!this.viewerSessions.has(principal)||resumed,'viewer-already-connected');
  }
  const map=role==='player'?this.playerSessions:this.viewerSessions;
  const old=map.get(principal);
  if(old&&old!==st){this.send(old,frame(TYPE.REJECT,{code:'replaced-by-reconnect'}));old.session.close?.(4001,'replaced');}
  map.set(principal,st);
  const newToken=this.host.resumeStore.refresh(token,this.id,principal,role)||this.host.resumeStore.issue(this.id,principal,role);
  st.role=role;st.principal=principal;st.resumeToken=newToken;st.lastEvents={state:Math.max(0,Number(msg.lastEvents?.state??msg.lastEvent)||0),presentation:Math.max(0,Number(msg.lastEvents?.presentation)||0)};st.lastEvent=st.lastEvents.state;if(role==='player'){this.disconnected.delete(principal);e.setConnected(principal,true);}
  const projection=e.snapshot(role==='player'?principal:null);
  this.send(st,frame(resumed?TYPE.RESUMED:TYPE.MATCH,{match:this.id,role,principal,player:role==='player'?principal:null,phase:e.phase,revision:e.revision,players:projection.players??null,resumeToken:newToken,serverEvent:e.eventWindow().newest,streams:st.streams,onboarding:this.getOnboardingState()}));
  this.flush(st,true);
 }

 getDefinition(){
  this.ensureEngine();
  return this.definition;
 }
 getOnboarding(){
  const def=this.getDefinition();
  return normalizePlan(typeof def==='object' ? def.onboarding : null);
 }
 getOnboardingState(){
  const plan=this.getOnboarding();
  if(!plan)return null;
  return { ...plan, status:this.onboarding?.status||((this.engine?.phase==='lobby')?'ready':'completed'), startedAt:this.onboarding?.startedAt||null };
 }
 broadcastTutorial(){for(const st of this.sessions.values())if(st.role)this.send(st,frame(TYPE.TUTORIAL,{match:this.id,onboarding:this.getOnboardingState()}));}
 onTutorialDone(st,msg){assert(st.role==='viewer','viewer-required');const plan=this.getOnboarding();assert(plan?.gateStart,'tutorial-not-required');assert(this.pendingStart,'tutorial-not-pending');if(msg?.skip&&!plan.allowSkip)throw Object.assign(new Error('tutorial-skip-disabled'),{code:'tutorial-skip-disabled'});return this.completeTutorial(msg?.skip?'skip':'viewer');}
 completeTutorial(reason='complete'){
  if(!this.pendingStart)return {started:false};
  if(this._tutorialTimer){clearTimeout(this._tutorialTimer);this._tutorialTimer=null;}
  const pending=this.pendingStart;this.pendingStart=null;
  const out=this.ensureEngine().start(pending.options||{});
  const plan=this.getOnboarding();this.onboarding={status:'completed',reason,startedAt:this.onboarding?.startedAt||Date.now(),completedAt:Date.now(),plan};
  this.broadcast();return out;
 }
 onReady(st,msg){assert(st.role==='player','player-required');const value=this.ensureEngine().ready(st.principal,msg.value!==false);this.broadcast();return value;}
 onResume(st,msg){assert(st.role&&st.principal,'not-joined');assert(st.resumeToken,'no-resume-token');const oldToken=st.resumeToken;const rec=this.host.resumeStore.consume(oldToken,this.id,st.principal,st.role);assert(rec,'invalid-resume-token');this.host.resumeStore.revoke(oldToken);st.resumeToken=this.host.resumeStore.issue(this.id,st.principal,st.role);st.lastEvents={state:Math.max(0,Number(msg.lastEvents?.state??msg.lastEvent??st.lastEvents.state)||0),presentation:Math.max(0,Number(msg.lastEvents?.presentation??st.lastEvents.presentation)||0)};st.lastEvent=st.lastEvents.state||0;this.send(st,frame(TYPE.RESUMED,{match:this.id,role:st.role,principal:st.principal,player:st.role==='player'?st.principal:null,resumeToken:st.resumeToken,serverEvent:this.ensureEngine().eventWindow().newest,streams:st.streams}));this.flush(st,true);}
 onSnapshot(st){assert(st.role&&st.principal,'not-joined');const e=this.ensureEngine();this.sendSnapshot(st);this.flushEvents(st);}
 onCommand(st,msg){const e=this.ensureEngine();assert(st.role==='player','player-required');const cid=msg.cid==null?null:String(msg.cid);let cache=this.principalCommands.get(st.principal);if(!cache){cache=new Map();this.principalCommands.set(st.principal,cache);}if(cid&&cache.has(cid)){this.host.metrics.duplicate();this.send(st,cache.get(cid));this.flush(st,false);return;}this.host.metrics.command();const result=e.tryDispatch(st.principal,msg.cmd||msg.command);const response=frame(TYPE.RESULT,{cid,...result});if(cid){cache.set(cid,response);if(cache.size>this.host.maxDedup)cache.delete(cache.keys().next().value);}this.send(st,response);this.flushAfterCommand(st,result.changed===true);}
 flush(st,forceSnapshot=false){const e=this.ensureEngine();if(forceSnapshot)this.sendSnapshot(st);this.flushEvents(st);}
 flushAfterCommand(actor,forceSnapshot=false){for(const st of this.sessions.values()){if(!st.role)continue;this.flush(st,st===actor&&forceSnapshot);}}
 flushPrincipal(role,principal,forceSnapshot=false){const st=(role==='player'?this.playerSessions:this.viewerSessions).get(principal);if(st)this.flush(st,forceSnapshot);}
 sendSnapshot(st,reason=null,includeCursors=false){const e=this.ensureEngine();const body={revision:e.revision,data:e.snapshot(st.role==='player'?st.principal:null)};if(reason)body.reason=reason;if(includeCursors){body.eventCursors={};for(const stream of st.streams||['state'])body.eventCursors[stream]=e.eventWindow(stream).newest;}this.send(st,frame(TYPE.SNAPSHOT,body));}
 flushEvents(st){const e=this.ensureEngine();const viewer=st.role==='player'?st.principal:null;const streams=st.streams||['state'];let gap=false;for(const stream of streams){const w=e.eventWindow(stream);const cursor=Number(st.lastEvents?.[stream]||0);if(cursor<w.oldest-1){gap=true;break;}}if(gap){this.sendSnapshot(st,'event-gap',true);for(const stream of streams)st.lastEvents[stream]=e.eventWindow(stream).newest;st.lastEvent=st.lastEvents.state||0;return;}for(const stream of streams){const cursor=Number(st.lastEvents?.[stream]||0);const list=e.eventsSince(cursor,viewer,stream);if(list.length){const to=list[list.length-1].seq;st.lastEvents[stream]=to;if(stream==='state')st.lastEvent=to;this.host.metrics.events(list.length);this.send(st,frame(TYPE.EVENTS,{stream,from:list[0].id,to,revision:e.revision,data:list}));}}}
 broadcast(){for(const st of this.sessions.values())if(st.role)this.flush(st,true);}
 send(st,msg){if(!st.alive)return false;const type=TYPE_NAME.get(msg.t)||'';const result=st.session.send(msg);const bytes=typeof result==='number'?result:0;const ok=typeof result==='boolean'?result:bytes>0;this.host.metrics.frame(bytes,type);return ok;}
 sendError(st,e){this.host.metrics.commandError();this.send(st,frame(TYPE.ERROR,{code:e.code||'server-error',message:e.message||String(e)}));}
 close(){if(this._tutorialTimer){clearTimeout(this._tutorialTimer);this._tutorialTimer=null;}for(const st of this.sessions.values())st.session.close?.();for(const player of this.playerSessions.keys())this.host.resumeStore.revokePrincipal(this.id,player);for(const viewer of this.viewerSessions.keys())this.host.resumeStore.revokePrincipal(this.id,viewer);this.sessions.clear();this.playerSessions.clear();this.viewerSessions.clear();this.disconnected.clear();this.principalCommands.clear();}
}
module.exports={MatchHost};
