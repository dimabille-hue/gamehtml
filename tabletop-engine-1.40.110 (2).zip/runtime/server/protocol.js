'use strict';
const VERSION = 1;
const TYPE = Object.freeze({
  HELLO:1, JOIN:2, COMMAND:3, RESUME:4, PING:5, SNAPSHOT_REQ:6, READY:7, TUTORIAL_DONE:8,
  WELCOME:101, SNAPSHOT:102, EVENTS:103, RESULT:104, ERROR:105, PONG:106, REJECT:107, MATCH:108, RESUMED:109, TUTORIAL:110
});
function encode(message){ if(!message||typeof message!=='object') throw new TypeError('message-required'); return JSON.stringify(message); }
function decode(payload){ const v=typeof payload==='string'?JSON.parse(payload):payload; if(!v||typeof v!=='object'||!Number.isInteger(v.t)) throw new Error('invalid-frame'); if(v.v!=null&&v.v!==VERSION) throw new Error('unsupported-protocol-version'); return v; }
function frame(t, body={}){ return {v:VERSION,t,...body}; }
module.exports={VERSION,TYPE,encode,decode,frame};
