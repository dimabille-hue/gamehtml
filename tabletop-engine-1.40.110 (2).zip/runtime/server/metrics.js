'use strict';
class ServerMetrics {
  constructor(){ this.reset(); }
  reset(){ this.startedAt=Date.now(); this.sessions=0; this.activeSessions=0; this.matches=0; this.commands=0; this.commandErrors=0; this.bytesOut=0; this.framesOut=0; this.snapshots=0; this.eventBatches=0; this.eventsOut=0; this.duplicates=0; }
  sessionOpen(){ this.sessions++; this.activeSessions++; }
  sessionClose(){ if(this.activeSessions>0) this.activeSessions--; }
  command(){ this.commands++; }
  commandError(){ this.commandErrors++; }
  duplicate(){ this.duplicates++; }
  frame(bytes, type){ this.framesOut++; this.bytesOut += bytes|0; if(type==='SNAPSHOT') this.snapshots++; if(type==='EVENTS') this.eventBatches++; }
  events(n){ this.eventsOut += n|0; }
  matchCreate(){ this.matches++; }
  snapshot(){ const ms=Math.max(1,Date.now()-this.startedAt); return {uptimeMs:ms,sessions:this.sessions,activeSessions:this.activeSessions,matches:this.matches,commands:this.commands,commandErrors:this.commandErrors,duplicates:this.duplicates,framesOut:this.framesOut,bytesOut:this.bytesOut,snapshots:this.snapshots,eventBatches:this.eventBatches,eventsOut:this.eventsOut,commandsPerSec:this.commands*1000/ms,framesPerSec:this.framesOut*1000/ms}; }
}
module.exports={ServerMetrics};
