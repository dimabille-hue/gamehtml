# Server Adapter v1.9

The server layer is transport/session infrastructure only. It has no dependency on a concrete game.

## Roles

- `player`: may send game commands and receives private + public projections.
- `viewer`: TV/display-style observer; receives public projections/events and cannot send game commands.

## Reconnect

Resume tokens are scoped to `(match, principal, role)`, expire, and rotate after successful resume. Command CIDs are retained at player scope so retry after reconnect is idempotent.

## Transport

The bundled WebSocket adapter is deliberately small and transport-focused. It accepts single-frame text messages, enforces a configurable frame limit and rejects fragmented/reserved frames. A full WebSocket implementation may be substituted without changing `MatchHost` or `core`.
