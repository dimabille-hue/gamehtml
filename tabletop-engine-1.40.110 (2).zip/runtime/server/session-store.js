'use strict';
const crypto = require('node:crypto');
class ResumeStore {
  constructor(options = {}) { this.ttlMs=Math.max(1000,Number(options.ttlMs??120000)); this.tokens=new Map(); this.now=options.now||(()=>Date.now()); }
  issue(matchId,principal,role='player'){ const token=crypto.randomBytes(32).toString('base64url'); const rec={matchId:String(matchId),principal:String(principal),role:String(role),expiresAt:this.now()+this.ttlMs}; this.tokens.set(token,rec); return token; }
  consume(token,matchId,principal=null,role=null){ if(!token)return null; const key=String(token),rec=this.tokens.get(key); if(!rec)return null; if(rec.expiresAt<=this.now()){this.tokens.delete(key);return null;} if(String(matchId)!==rec.matchId)return null; if(principal!=null&&String(principal)!==rec.principal)return null; if(role!=null&&String(role)!==rec.role)return null; return {...rec,token:key,playerId:rec.principal}; }
  refresh(oldToken,matchId,principal,role=null){ const rec=this.consume(oldToken,matchId,principal,role); if(!rec)return null; this.tokens.delete(String(oldToken)); return this.issue(matchId,principal,role??rec.role); }
  revoke(token){this.tokens.delete(String(token));}
  revokePrincipal(matchId,principal){ for(const [token,rec] of this.tokens){ if(rec.matchId===String(matchId)&&rec.principal===String(principal)) this.tokens.delete(token); } }
  revokePlayer(matchId,playerId){ this.revokePrincipal(matchId,playerId); }
  prune(){const now=this.now();for(const [token,rec] of this.tokens)if(rec.expiresAt<=now)this.tokens.delete(token);}
  size(){return this.tokens.size;}
}
module.exports={ResumeStore};
