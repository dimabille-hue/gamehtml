'use strict';

function normalizePlan(plan) {
  if (!plan) return null;
  if (typeof plan !== 'object' || Array.isArray(plan)) throw new TypeError('invalid-onboarding-plan');
  const steps = Array.isArray(plan.steps) ? plan.steps : [];
  if (!steps.length) return null;
  const normalized = steps.map((step, index) => {
    if (!step || typeof step !== 'object') throw new TypeError(`invalid-onboarding-step:${index}`);
    return {
      id: String(step.id ?? `step-${index + 1}`),
      title: String(step.title ?? ''),
      body: String(step.body ?? ''),
      durationMs: Math.max(0, Number(step.durationMs ?? 5000)),
      image: step.image == null ? null : String(step.image),
      accent: step.accent == null ? null : String(step.accent),
      focus: step.focus == null ? null : String(step.focus),
      demo: step.demo && typeof step.demo === 'object' ? { ...step.demo } : null
    };
  });
  const total = normalized.reduce((sum, step) => sum + step.durationMs, 0);
  const autoStartAfterMs = Math.max(1000, Number(plan.autoStartAfterMs ?? Math.max(total + 1000, 8000)));
  return {
    id: String(plan.id ?? 'tutorial'),
    version: Number(plan.version ?? 1),
    gateStart: plan.gateStart === true,
    allowSkip: plan.allowSkip !== false,
    totalDurationMs: total,
    autoStartAfterMs,
    steps: normalized
  };
}

module.exports = { normalizePlan };
