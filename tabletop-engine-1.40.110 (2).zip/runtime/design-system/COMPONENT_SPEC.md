# Component specification

| Component | Use | Mobile | TV/Desktop | Semantic rules |
|---|---|---|---|---|
| Panel | Group related information | Compact | Persistent | Never use color alone to convey state |
| Icon button | Secondary or compact action | Primary | Optional | >=44px touch target; aria-label required |
| Action button | Primary game action | Icon-only preferred | Icon + text allowed | Disabled state must be visible |
| Chip | Small state/identity | Allowed | Allowed | Keep <= 1–2 short tokens |
| Meter | HP/fuel/moves | Compact | Compact | Pair with numeric value |
| Bottom sheet | Detail/decision | Primary | Optional | Focus trap required when modal |
| Hex cell | Board interaction | Primary | Primary | Selected/reachable/danger are visually distinct |
| Event | State/presentation feed | Sheet/overlay | Persistent feed | Tone is supplementary, not sole meaning |
