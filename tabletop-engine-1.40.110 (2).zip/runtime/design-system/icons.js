export const LAST_SECTOR_ICONS = Object.freeze({
  move: 'i-move',
  attack: 'i-attack',
  scan: 'i-scan',
  collect: 'i-collect',
  teleport: 'i-teleport',
  repair: 'i-repair',
  fuel: 'i-fuel',
  trap: 'i-trap',
  end: 'i-end',
  menu: 'i-menu',
  info: 'i-info'
});

export function iconUse(id, { label = '', className = '' } = {}) {
  const symbol = LAST_SECTOR_ICONS[id] ?? id;
  return `<svg class="${className}" aria-hidden="${label ? 'false' : 'true'}" role="${label ? 'img' : 'presentation'}"${label ? ` aria-label="${label}"` : ''}><use href="#${symbol}"></use></svg>`;
}
