export const LAST_SECTOR_TOKENS = Object.freeze({
  player: '#25D6FF',
  ally: '#47E09C',
  enemy: '#FF4D59',
  warning: '#F5BD43',
  anomaly: '#B978FF',
  info: '#5AAAFF',
  neutral: '#A5B3BD',
  background: '#02060A'
});
