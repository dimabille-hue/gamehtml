# Last Sector Design System v1.0

Production-ready visual system derived from the Last Sector concept board and tuned for the existing runtime.

## Principles

- Player is mobile-first. The map is the primary surface.
- TV is a separate cinematic composition; it is not a scaled Player UI.
- Icons are the primary mobile action affordance; every icon-only control has an accessible name.
- State colors are semantic and consistent across Player/TV.
- Visual effects are optional presentation work and never part of the game engine.
- Reduced-motion and safe-area behavior are first-class.

## Include

For a full UI:

```html
<link rel="stylesheet" href="design-system/index.css">
```

For Player:

```html
<link rel="stylesheet" href="design-system/player.css">
```

For TV:

```html
<link rel="stylesheet" href="design-system/tv.css">
```

## Token policy

Use semantic tokens (`--ls-color-player`, `--ls-color-enemy`, etc.) in components. Do not hard-code palette values in game UI code.

## Responsive contract

- Mobile: <= 600px, icon-first action dock, overlays/bottom sheets, map dominant.
- Tablet: 601–900px, map remains dominant; secondary information may appear in sheets/drawers.
- Desktop: > 900px, persistent secondary rail is allowed.
- TV: use `tv.css`; composition is independent of Player UI.

## Accessibility contract

- Touch targets: minimum 44×44 CSS px.
- `:focus-visible` is required for keyboard navigation.
- Icon-only buttons must have `aria-label`.
- `prefers-reduced-motion` disables decorative motion.
- Do not encode game-state meaning by color alone.

## Component inventory

Foundation: panel, icon button, action button, chip, meter, event, bottom sheet, hex cell.

Recommended game-specific components: ship marker, tile/object marker, resource badge, turn badge, objective card, event renderer.

## No coupling rule

The design system must not import `games/*`, `core/*`, server code, or protocol code. Game UI consumes projections/events and maps them to visual components.
