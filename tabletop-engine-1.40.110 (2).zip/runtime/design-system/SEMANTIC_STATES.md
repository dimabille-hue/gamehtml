# Semantic states

| Token | Meaning | Default visual cue |
|---|---|---|
| player | current player / own entity | cyan |
| ally | friendly entity | green |
| enemy | hostile entity / destructive state | red |
| warning | caution / cost / end-turn | amber |
| anomaly | anomalous / supernatural / unknown | violet |
| info | neutral interactive information | blue |
| neutral | non-interactive environment | gray |
| focus | keyboard/touch focus | bright cyan outline |

Never use color as the only semantic cue. Pair it with icon, shape, label, or layout.
