'use strict';

/**
 * Creates a transport factory compatible with SessionClient.
 * No game knowledge; works in browser or Node when a WebSocket constructor is supplied.
 */
function createWebSocketTransport(options = {}) {
  const url = String(options.url || '');
  if (!url) throw new TypeError('websocket-url-required');
  const WebSocketCtor = options.WebSocketCtor || globalThis.WebSocket;
  if (typeof WebSocketCtor !== 'function') throw new Error('websocket-constructor-required');
  const protocols = options.protocols;
  return () => new Promise((resolve, reject) => {
    let socket;
    try { socket = protocols ? new WebSocketCtor(url, protocols) : new WebSocketCtor(url); }
    catch (error) { reject(error); return; }
    let settled = false;
    const fail = error => { if (!settled) { settled = true; reject(error instanceof Error ? error : new Error('websocket-connect-failed')); } };
    socket.addEventListener?.('open', () => { if (!settled) { settled = true; resolve(socket); } });
    socket.addEventListener?.('error', fail);
    if ('onopen' in socket) socket.onopen = () => { if (!settled) { settled = true; resolve(socket); } };
    if ('onerror' in socket) socket.onerror = fail;
  });
}

module.exports = { createWebSocketTransport };
