// AUTO-GENERATED BROWSER MODULE. DO NOT EDIT.
// Source: client/player-client.js
// Source SHA-256: 7169f62ae9efc0087d6db983859a6c6dabd9ba88f4ff40bb2a5817d5f1df5eae

import { SessionClient } from './session-client.js'; class PlayerClient extends SessionClient { constructor(options={}){super({...options,role:'player'});} } export { PlayerClient };
