// AUTO-GENERATED BROWSER MODULE. DO NOT EDIT.
// Source: client/transports/websocket.js
// Source SHA-256: 55cbac48a80b0d91271418d75d1be78a4627459599aa138997453b0f3cc0070e

/**
 * Creates a transport factory compatible with SessionClient.
 * No game knowledge; works in browser or Node when a WebSocket constructor is supplied.
 */
function createWebSocketTransport(options = {}) {
  const url = String(options.url || '');
  if (!url) throw new TypeError('websocket-url-required');
  const WebSocketCtor = options.WebSocketCtor || globalThis.WebSocket;
  if (typeof WebSocketCtor !== 'function') throw new Error('websocket-constructor-required');
  const protocols = options.protocols;
  return () => new Promise((resolve, reject) => {
    let socket;
    try { socket = protocols ? new WebSocketCtor(url, protocols) : new WebSocketCtor(url); }
    catch (error) { reject(error); return; }
    let settled = false;
    const fail = error => { if (!settled) { settled = true; reject(error instanceof Error ? error : new Error('websocket-connect-failed')); } };
    socket.addEventListener?.('open', () => { if (!settled) { settled = true; resolve(socket); } });
    socket.addEventListener?.('error', fail);
    if ('onopen' in socket) socket.onopen = () => { if (!settled) { settled = true; resolve(socket); } };
    if ('onerror' in socket) socket.onerror = fail;
  });
}

export { createWebSocketTransport };
