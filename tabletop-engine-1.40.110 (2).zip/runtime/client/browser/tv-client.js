// AUTO-GENERATED BROWSER MODULE. DO NOT EDIT.
// Source: client/tv-client.js
// Source SHA-256: fbe472f7ea3f0ff415ee248a143b6d7269ff9493fee35f364926c25375dbdcd0

import { SessionClient } from './session-client.js'; class TvClient extends SessionClient { constructor(options={}){super({...options,role:'viewer'});} } export { TvClient };
