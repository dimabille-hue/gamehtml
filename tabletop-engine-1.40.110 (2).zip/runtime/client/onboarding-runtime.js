'use strict';

class OnboardingRuntime {
  constructor(options = {}) {
    this.client = options.client;
    this.viewer = options.viewer || null;
    this.plan = null;
    this.listeners = new Set();
    this.active = false;
    if (this.client) {
      const previous = this.client.onTutorial;
      this.client.onTutorial = (plan, msg) => {
        this.set(plan, msg);
        previous?.(plan, msg);
      };
    }
  }
  on(fn) { if (typeof fn !== 'function') throw new TypeError('listener-required'); this.listeners.add(fn); return () => this.listeners.delete(fn); }
  emit() { for (const fn of this.listeners) fn(this.plan); }
  set(plan, msg = null) { this.plan = plan ? { ...plan } : null; this.active = !!plan && plan.status === 'playing'; this.emit(); return msg; }
  complete({ skip = false } = {}) { if (!this.client || !this.active) return false; this.client.send({v:1,t:8,skip:!!skip}); return true; }
}
module.exports = { OnboardingRuntime };
