'use strict'; const {SessionClient}=require('./session-client'); class TvClient extends SessionClient { constructor(options={}){super({...options,role:'viewer'});} } module.exports={TvClient};
