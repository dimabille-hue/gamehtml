'use strict';
const { ClientStateStore } = require('./state-store');

/**
 * Game-agnostic runtime facade for Player/TV applications.
 * It wires protocol messages to state/events without knowing their meaning.
 */
class ClientRuntime {
  constructor(client, options = {}) {
    if (!client) throw new TypeError('client-required');
    this.client = client;
    this.store = options.store || new ClientStateStore({ stateReducer: options.stateReducer });
    this.listeners = new Map();
    this.previous = {
      onSnapshot: client.onSnapshot,
      onEvents: client.onEvents,
      onResult: client.onResult,
      onState: client.onState,
      onError: client.onError,
      onMessage: client.onMessage
    };
    client.onSnapshot = (data, msg) => { this.store.applySnapshot(msg); this.emit('snapshot', data, msg); this.previous.onSnapshot?.(data, msg); };
    client.onEvents = (events, msg) => { this.store.applyEvents(msg); this.emit('events', events, msg); this.previous.onEvents?.(events, msg); };
    client.onResult = msg => { this.emit('result', msg); this.previous.onResult?.(msg); };
    client.onState = (state, detail) => { this.emit('state', state, detail); this.previous.onState?.(state, detail); };
    client.onError = error => { this.emit('error', error); this.previous.onError?.(error); };
    client.onMessage = msg => { this.emit('message', msg); this.previous.onMessage?.(msg); };
  }
  on(name, fn) { if (typeof fn !== 'function') throw new TypeError('listener-required'); let set=this.listeners.get(name); if(!set)this.listeners.set(name,set=new Set()); set.add(fn); return () => set.delete(fn); }
  emit(name, ...args) { const set=this.listeners.get(name); if(set) for(const fn of set) fn(...args); }
  start() { return this.client.start(); }
  stop() { return this.client.stop(); }
  command(command, cid) { return this.client.command(command, cid); }
  ready(value=true) { return this.client.ready(value); }
  requestSnapshot() { return this.client.requestSnapshot(); }
  get snapshot() { return this.store.snapshot; }
  get revision() { return this.store.revision; }
  get lastEvent() { return this.store.lastEvent; }
  get lastEvents() { return { ...this.store.lastEvents }; }
}
module.exports = { ClientRuntime };
