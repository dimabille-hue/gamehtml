# ReconnectingClient

Transport-agnostic client session helper.

It keeps the player ID, resume token, last event cursor and pending command
CIDs. The actual WebSocket implementation is injected through `connect()`.

On disconnect it retries with exponential backoff, reconnects using the resume
token and re-sends pending commands with the original CID.
