'use strict';
const http=require('node:http');
const fs=require('node:fs');
const path=require('node:path');
const {GamePackHost}=require('../runtime/pack-host');
const launcherRoot=path.resolve(__dirname,'public');
const runtimeRoot=path.resolve(__dirname,'..','runtime');
const engineVersion=JSON.parse(fs.readFileSync(path.resolve(__dirname,'..','package.json'),'utf8')).version;
const packHost=new GamePackHost({engineVersion,packDir:process.env.TABLETOP_GAME_PACKS_DIR});
const MIME=Object.freeze({'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.mjs':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.json':'application/json; charset=utf-8','.svg':'image/svg+xml','.png':'image/png','.jpg':'image/jpeg','.webp':'image/webp'});
function safe(root,rel){const file=path.resolve(root,rel.replace(/^\/+/,''));return file===path.resolve(root)||file.startsWith(path.resolve(root)+path.sep)?file:null;}
function catalog(){const games=packHost.list();return {runtimeVersion:engineVersion,games,errors:packHost.errorsSnapshot()};}
function resolvePath(urlPath){
 const u=decodeURIComponent(urlPath.split('?')[0]||'/');
 if(u==='/'||u==='/index.html')return{file:path.join(launcherRoot,'index.html')};
 if(u==='/catalog.json')return{json:catalog()};
 if(u==='/pack-errors.json')return{json:{errors:packHost.errorsSnapshot()}};
 if(u.startsWith('/client/'))return{file:safe(runtimeRoot,u.slice(1))};
 if(u.startsWith('/presentation/'))return{file:safe(runtimeRoot,u.slice(1))};
 if(u.startsWith('/design-system/'))return{file:safe(runtimeRoot,u.slice(1))};
 if(u.startsWith('/games/')){const m=u.match(/^\/games\/([^/]+)\/(.*)$/);if(!m)return null;try{return{file:packHost.resolveFile(m[1],m[2])};}catch(_){return null;}}
 return null;
}
function serve(req,res){const t=resolvePath(req.url||'/');if(!t){res.writeHead(404);return res.end('Not found');}if(t.json){const data=Buffer.from(JSON.stringify(t.json));res.writeHead(200,{'content-type':'application/json; charset=utf-8','cache-control':'no-store'});return res.end(data);}fs.readFile(t.file,(err,data)=>{if(err){res.writeHead(err.code==='ENOENT'?404:500);return res.end(err.code==='ENOENT'?'Not found':'Server error');}res.writeHead(200,{'content-type':MIME[path.extname(t.file)]||'application/octet-stream','cache-control':'no-store'});res.end(data);});}
if(require.main===module){const port=Number(process.env.PORT||8090);http.createServer(serve).listen(port,'0.0.0.0',()=>console.log(`Tabletop launcher: http://0.0.0.0:${port} packs=${packHost.packDir}`));}
module.exports={serve,packHost,catalog};
